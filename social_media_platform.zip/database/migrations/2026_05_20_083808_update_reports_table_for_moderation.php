<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('reports', function (Blueprint $table) {
            $table->dropForeign(['reported_user_id']);
            $table->dropColumn('reported_user_id');
            
            $table->unsignedBigInteger('reportable_id')->after('reporter_id');
            $table->string('reportable_type')->after('reportable_id');
            $table->enum('status', ['pending', 'under_review', 'approved', 'removed'])->default('pending')->after('reason');
            $table->text('admin_notes')->nullable()->after('status');
        });
    }

    public function down(): void
    {
        Schema::table('reports', function (Blueprint $table) {
            $table->dropColumn(['reportable_id', 'reportable_type', 'status', 'admin_notes']);
            $table->foreignId('reported_user_id')->constrained('users')->cascadeOnDelete();
        });
    }
};
