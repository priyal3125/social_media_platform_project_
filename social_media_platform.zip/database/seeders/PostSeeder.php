<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class PostSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $users = \App\Models\User::all();
        if ($users->isEmpty()) return;

        $captions = [
            'Exploring the hidden gems of the city today! ✨',
            'Golden hour never looked so good. #lifestyle',
            'Focus on the good and the good will find you.',
            'Working on big things. Stay tuned! 🚀',
            'Weekend vibes only. ☕️',
            'Collecting moments, not things.',
            'Consistency is the key to success. #growth',
            'Life is better when you are smiling.'
        ];

        foreach ($users as $user) {
            // Create 3-5 posts per user
            $count = rand(3, 5);
            for ($i = 0; $i < $count; $i++) {
                \App\Models\Post::create([
                    'user_id' => $user->id,
                    'title' => 'Post by ' . $user->name,
                    'content' => $captions[array_rand($captions)],
                    'views_count' => rand(100, 5000),
                    'privacy' => 'public',
                    'created_at' => now()->subDays(rand(1, 30))
                ]);
            }
        }
    }
}
