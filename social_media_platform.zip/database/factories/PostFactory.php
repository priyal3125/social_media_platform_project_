<?php

namespace Database\Factories;

use App\Models\Post;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<Post>
 */
class PostFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $category = fake()->randomElement([
            'Travel', 'Food', 'Nature', 'Art', 'Fashion', 'Tech', 'People',
        ]);

        $hashtagMap = [
            'Travel'  => ['#travel', '#wanderlust', '#adventure', '#explore', '#vacation'],
            'Food'    => ['#food', '#foodie', '#recipe', '#cooking', '#delicious'],
            'Nature'  => ['#nature', '#wildlife', '#outdoors', '#landscape', '#green'],
            'Art'     => ['#art', '#design', '#creative', '#illustration', '#painting'],
            'Fashion' => ['#fashion', '#style', '#ootd', '#outfit', '#trendy'],
            'Tech'    => ['#tech', '#coding', '#developer', '#gadgets', '#innovation'],
            'People'  => ['#people', '#portrait', '#lifestyle', '#community', '#moments'],
        ];

        $tags = fake()->randomElements($hashtagMap[$category], rand(2, 4));

        return [
            'user_id'    => \App\Models\User::factory(),
            'title'      => fake()->boolean(70) ? fake()->sentence(6) : null,
            'content'    => fake()->paragraphs(2, true),
            'privacy'    => fake()->randomElement(['public', 'public', 'friends', 'private']),
            'category'   => $category,
            'hashtags'   => implode(' ', $tags),
            'created_at' => fake()->dateTimeBetween('-1 year', 'now'),
            'updated_at' => now(),
        ];
    }
}
