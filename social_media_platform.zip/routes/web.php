<?php

use App\Http\Controllers\ProfileController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\PostController;
use App\Http\Controllers\CommentController;
use App\Http\Controllers\LikeController;
use App\Http\Controllers\FollowController;
use App\Http\Controllers\MessageController;
use App\Http\Controllers\StoryController;
use App\Http\Controllers\ReelsController;
use App\Http\Controllers\NotificationController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    if (auth()->check()) {
        return redirect()->route('home');
    }
    return view('welcome');
});

Route::middleware(['auth', 'verified'])->group(function () {
    // Home Feed
    Route::get('/home', [HomeController::class, 'index'])->name('home');
    Route::get('/explore', [HomeController::class, 'explore'])->name('explore');
    Route::get('/reels', [HomeController::class, 'reels'])->name('reels.index');
    Route::get('/reels/create', [ReelsController::class, 'create'])->name('reels.create');
    Route::post('/reels', [ReelsController::class, 'store'])->name('reels.store');
    
    // Posts
    Route::resource('posts', PostController::class);
    
    // Likes (AJAX)
    Route::post('/posts/{post}/like', [LikeController::class, 'toggleLike'])->name('posts.like');

    // Save / Unsave (AJAX)
    Route::post('/posts/{post}/save', [\App\Http\Controllers\SavedPostController::class, 'toggle'])->name('posts.save');

    Route::post('/posts/{post}/view', [PostController::class, 'view'])->name('posts.view');
    
    // Comments
    Route::post('/posts/{post}/comments', [CommentController::class, 'store'])->name('comments.store');
    
    // Profile
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
    
    // User Public Profile
    Route::get('/u/{username}', [ProfileController::class, 'show'])->name('profile.show');
    
    // Follow System
    Route::post('/u/{user}/follow', [FollowController::class, 'toggleFollow'])->name('users.follow');
    
    // Direct Messaging (Chat)
    Route::get('/messages', [MessageController::class, 'index'])->name('messages.index');
    Route::get('/messages/{user}', [MessageController::class, 'chat'])->name('messages.chat');
    Route::post('/messages/{user}', [MessageController::class, 'send'])->name('messages.send');
    Route::get('/messages/{user}/poll', [MessageController::class, 'poll'])->name('messages.poll');
    
    // Stories
    Route::post('/stories', [StoryController::class, 'store'])->name('stories.store');

    // Notifications
    Route::get('/notification', fn () => redirect()->route('notifications.index'))->name('notification');
    Route::get('/notifications', [NotificationController::class, 'index'])->name('notifications.index');
    Route::post('/notifications/read-all', [NotificationController::class, 'readAll'])->name('notifications.readAll');
    Route::get('/notifications/{notification}/open', [NotificationController::class, 'open'])->name('notifications.open');
});

// ============================================================
// ADMIN PANEL — Completely Separate from User Panel
// ============================================================

// Admin Auth (No middleware — public login page)
Route::prefix('admin')->name('admin.')->group(function () {
    Route::get('/login', [\App\Http\Controllers\Admin\AdminAuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [\App\Http\Controllers\Admin\AdminAuthController::class, 'login'])->name('login.submit');
    Route::post('/logout', [\App\Http\Controllers\Admin\AdminAuthController::class, 'logout'])->name('logout');
});

// Admin Protected Routes (Separate middleware)
Route::middleware(['auth', 'admin'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/', fn() => redirect()->route('admin.dashboard'));
    Route::get('/dashboard', [\App\Http\Controllers\Admin\DashboardController::class, 'index'])->name('dashboard');
    
    // Moderation
    Route::get('/moderation', [\App\Http\Controllers\Admin\ModerationController::class, 'index'])->name('moderation.index');
    Route::patch('/moderation/{report}', [\App\Http\Controllers\Admin\ModerationController::class, 'update'])->name('moderation.update');

    // Dedicated Sections
    Route::get('/analytics', [\App\Http\Controllers\Admin\AnalyticsController::class, 'index'])->name('analytics');
    Route::get('/reports', [\App\Http\Controllers\Admin\ReportsOverviewController::class, 'index'])->name('reports');
    Route::get('/audit-logs', [\App\Http\Controllers\Admin\AuditLogController::class, 'index'])->name('audit_logs');
    
    // Settings
    Route::get('/settings', [\App\Http\Controllers\Admin\SettingsController::class, 'index'])->name('settings.index');
    Route::patch('/settings', [\App\Http\Controllers\Admin\SettingsController::class, 'update'])->name('settings.update');
});

require __DIR__.'/auth.php';
