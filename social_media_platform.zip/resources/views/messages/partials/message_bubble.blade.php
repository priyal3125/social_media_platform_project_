@php
    $isSent = $msg->sender_id === auth()->id();
@endphp

<div class="d-flex {{ $isSent ? 'justify-content-end' : 'justify-content-start' }} mb-3">
    <div class="message-bubble-wrapper d-flex flex-column {{ $isSent ? 'align-items-end' : 'align-items-start' }}" style="max-width: 75%;">
        <div class="card border-0 shadow-sm px-3 py-2 rounded-4 {{ $isSent ? 'bg-primary text-white' : 'bg-light text-dark' }}">
            @if($msg->message)
                <p class="mb-0 text-break" style="font-size: 0.95rem; white-space: pre-line;">{{ $msg->message }}</p>
            @endif

            @if($msg->image)
                <div class="{{ $msg->message ? 'mt-2' : '' }}">
                    <img src="{{ asset('storage/' . $msg->image) }}" class="img-fluid rounded-3 message-image" style="max-height: 250px; object-fit: cover;" alt="Attached image">
                </div>
            @endif
        </div>
        <small class="text-muted mt-1 px-2" style="font-size: 0.75rem;">
            {{ $msg->created_at->diffForHumans() }}
            @if($isSent)
                <span class="ms-1 text-primary">
                    <i class="fa-solid {{ $msg->is_seen ? 'fa-check-double' : 'fa-check' }}"></i>
                </span>
            @endif
        </small>
    </div>
</div>
