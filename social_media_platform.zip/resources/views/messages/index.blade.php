<x-app-layout>
    <div class="row g-4 justify-content-center">
        <!-- Messages Main Wrapper Card -->
        <div class="col-md-11 col-lg-10">
            <div class="card shadow border-0 overflow-hidden" style="height: 75vh;">
                <div class="row g-0 h-100">
                    
                    <!-- Left Sidebar: Users List -->
                    <div class="col-12 col-md-4 border-end h-100 d-flex flex-column bg-white">
                        <div class="p-3 border-bottom d-flex align-items-center justify-content-between">
                            <h5 class="fw-bold mb-0 text-primary"><i class="fa-solid fa-comments me-2"></i>Messages</h5>
                        </div>
                        
                        <!-- Search and Conversations list -->
                        <div class="flex-grow-1 overflow-y-auto" style="max-height: calc(75vh - 65px);">
                            @if($chatUsers->isEmpty())
                                <div class="p-4 text-center text-muted">
                                    <i class="fa-regular fa-paper-plane fa-2x mb-3 text-muted opacity-50"></i>
                                    <p class="small mb-0">Follow active users to open up messaging channels!</p>
                                </div>
                            @else
                                <div class="list-group list-group-flush">
                                    @foreach($chatUsers as $cUser)
                                        @php
                                            $isActive = isset($user) && $user->id === $cUser->id;
                                        @endphp
                                        <a href="{{ route('messages.chat', $cUser->id) }}" class="list-group-item list-group-item-action border-0 px-3 py-3 d-flex align-items-center justify-content-between {{ $isActive ? 'bg-primary-subtle border-start border-primary border-4' : '' }}">
                                            <div class="d-flex align-items-center overflow-hidden">
                                                <img src="{{ $cUser->profile_photo ? asset('storage/'.$cUser->profile_photo) : 'https://ui-avatars.com/api/?name='.urlencode($cUser->name) }}" class="rounded-circle me-3" width="48" height="48" style="object-fit: cover;" alt="Avatar">
                                                <div class="overflow-hidden">
                                                    <h6 class="mb-0 fw-bold text-dark text-truncate">{{ $cUser->name }}</h6>
                                                    <span class="small text-muted text-truncate d-block">
                                                        @if($cUser->last_message)
                                                            @if($cUser->last_message->sender_id === auth()->id())
                                                                <span class="text-muted">You:</span>
                                                            @endif
                                                            {{ $cUser->last_message->message ?? 'Sent an image' }}
                                                        @else
                                                            {{ '@'.$cUser->username }}
                                                        @endif
                                                    </span>
                                                </div>
                                            </div>
                                            
                                            <div class="d-flex flex-column align-items-end ms-2 flex-shrink-0">
                                                @if($cUser->last_message)
                                                    <span class="small text-muted" style="font-size: 0.7rem;">
                                                        {{ $cUser->last_message->created_at->format('H:i') }}
                                                    </span>
                                                @endif
                                                @if($cUser->unread_count > 0)
                                                    <span class="badge bg-danger rounded-circle mt-1 px-2 py-1" style="font-size: 0.7rem;">
                                                        {{ $cUser->unread_count }}
                                                    </span>
                                                @endif
                                            </div>
                                        </a>
                                    @endforeach
                                </div>
                            @endif
                        </div>
                    </div>
                    
                    <!-- Right Sidebar: Active Chat Box -->
                    <div class="col-12 col-md-8 h-100 d-flex flex-column bg-light-subtle">
                        @isset($user)
                            <!-- Active Chat Header -->
                            <div class="p-3 bg-white border-bottom d-flex align-items-center justify-content-between">
                                <div class="d-flex align-items-center">
                                    <a href="{{ route('profile.show', $user->username) }}" class="text-decoration-none">
                                        <img src="{{ $user->profile_photo ? asset('storage/'.$user->profile_photo) : 'https://ui-avatars.com/api/?name='.urlencode($user->name) }}" class="rounded-circle me-3" width="44" height="44" style="object-fit: cover;" alt="Avatar">
                                    </a>
                                    <div>
                                        <a href="{{ route('profile.show', $user->username) }}" class="text-decoration-none text-dark">
                                            <h6 class="mb-0 fw-bold">{{ $user->name }}</h6>
                                        </a>
                                        <span class="small text-muted">{{ '@'.$user->username }}</span>
                                    </div>
                                </div>
                                <div>
                                    <a href="{{ route('profile.show', $user->username) }}" class="btn btn-sm btn-outline-secondary rounded-pill px-3">View Profile</a>
                                </div>
                            </div>
                            
                            <!-- Messages Area -->
                            <div id="chat-messages-container" class="flex-grow-1 p-3 overflow-y-auto" style="max-height: calc(75vh - 145px); background: #f8fafc;">
                                @if($messages->isEmpty())
                                    <div class="h-100 d-flex flex-column align-items-center justify-content-center text-muted">
                                        <i class="fa-regular fa-comments fa-3x mb-3 text-muted opacity-50"></i>
                                        <p class="mb-0 fw-semibold">No messages yet</p>
                                        <small class="small text-muted">Type something below to open conversation.</small>
                                    </div>
                                @else
                                    @foreach($messages as $msg)
                                        @include('messages.partials.message_bubble', ['msg' => $msg])
                                    @endforeach
                                @endif
                            </div>
                            
                            <!-- Message Input Form -->
                            <div class="p-3 bg-white border-top">
                                <form id="chat-send-form" action="{{ route('messages.send', $user->id) }}" method="POST" enctype="multipart/form-data">
                                    @csrf
                                    <!-- Image Attachment Preview -->
                                    <div id="image-preview-container" class="mb-2 d-none position-relative" style="width: 80px;">
                                        <img id="image-preview" src="#" class="img-fluid rounded border shadow-sm" style="max-height: 80px; object-fit: cover;" alt="Preview">
                                        <button type="button" id="remove-image-btn" class="btn btn-sm btn-danger rounded-circle position-absolute top-0 start-100 translate-middle p-1" style="line-height: 1; font-size: 0.6rem;">
                                            <i class="fa-solid fa-times"></i>
                                        </button>
                                    </div>
                                    
                                    <div class="input-group">
                                        <!-- Image Attachment Trigger -->
                                        <input type="file" name="image" id="chat-image-input" class="d-none" accept="image/*">
                                        <button type="button" class="btn btn-outline-secondary px-3" onclick="document.getElementById('chat-image-input').click();">
                                            <i class="fa-solid fa-paperclip"></i>
                                        </button>
                                        
                                        <!-- Message Field -->
                                        <input type="text" name="message" id="chat-message-input" class="form-control px-3" placeholder="Type a message..." autocomplete="off">
                                        
                                        <!-- Send Action -->
                                        <button type="submit" class="btn btn-primary px-4">
                                            <i class="fa-solid fa-paper-plane"></i>
                                        </button>
                                    </div>
                                </form>
                            </div>
                            
                            <!-- JavaScript Interactivity -->
                            <script>
                                document.addEventListener('DOMContentLoaded', function() {
                                    const container = document.getElementById('chat-messages-container');
                                    const form = document.getElementById('chat-send-form');
                                    const msgInput = document.getElementById('chat-message-input');
                                    const imgInput = document.getElementById('chat-image-input');
                                    const prevContainer = document.getElementById('image-preview-container');
                                    const prevImg = document.getElementById('image-preview');
                                    const removeImgBtn = document.getElementById('remove-image-btn');
                                    
                                    // Scroll to bottom helper
                                    function scrollToBottom() {
                                        container.scrollTop = container.scrollHeight;
                                    }
                                    scrollToBottom();
                                    
                                    // Handle image selection preview
                                    imgInput.addEventListener('change', function() {
                                        const file = this.files[0];
                                        if (file) {
                                            const reader = new FileReader();
                                            reader.onload = function(e) {
                                                prevImg.src = e.target.result;
                                                prevContainer.classList.remove('d-none');
                                            };
                                            reader.readAsDataURL(file);
                                        }
                                    });
                                    
                                    // Remove image selection
                                    removeImgBtn.addEventListener('click', function() {
                                        imgInput.value = '';
                                        prevContainer.classList.add('d-none');
                                    });
                                    
                                    // Submit Message via AJAX
                                    form.addEventListener('submit', function(e) {
                                        e.preventDefault();
                                        
                                        const text = msgInput.value.trim();
                                        const files = imgInput.files;
                                        
                                        if (!text && files.length === 0) return;
                                        
                                        const formData = new FormData(form);
                                        
                                        // Clear input values immediately for snappier UI
                                        msgInput.value = '';
                                        imgInput.value = '';
                                        prevContainer.classList.add('d-none');
                                        
                                        fetch(form.action, {
                                            method: 'POST',
                                            headers: {
                                                'X-Requested-With': 'XMLHttpRequest'
                                            },
                                            body: formData
                                        })
                                        .then(res => res.json())
                                        .then(data => {
                                            if (data.success) {
                                                // Remove empty states if present
                                                const emptyState = container.querySelector('.fa-regular.fa-comments');
                                                if (emptyState) {
                                                    container.innerHTML = '';
                                                }
                                                // Append bubble
                                                container.insertAdjacentHTML('beforeend', data.html);
                                                scrollToBottom();
                                            }
                                        })
                                        .catch(err => console.error("Send Error: ", err));
                                    });
                                    
                                    // Chat Polling for live messaging without heavy packages
                                    const pollUrl = "{{ route('messages.poll', $user->id) }}";
                                    setInterval(function() {
                                        fetch(pollUrl, {
                                            method: 'GET',
                                            headers: {
                                                'X-Requested-With': 'XMLHttpRequest'
                                            }
                                        })
                                        .then(res => res.json())
                                        .then(data => {
                                            if (data.html && data.html.trim().length > 0) {
                                                const emptyState = container.querySelector('.fa-regular.fa-comments');
                                                if (emptyState) {
                                                    container.innerHTML = '';
                                                }
                                                container.insertAdjacentHTML('beforeend', data.html);
                                                scrollToBottom();
                                            }
                                        })
                                        .catch(err => console.error("Poll Error: ", err));
                                    }, 2500);
                                    
                                });
                            </script>
                        @else
                            <!-- Empty Messaging State -->
                            <div class="h-100 d-flex flex-column align-items-center justify-content-center text-muted bg-light">
                                <i class="fa-solid fa-paper-plane fa-4x mb-4 text-primary opacity-75"></i>
                                <h4 class="fw-bold text-dark">Your Direct Messages</h4>
                                <p class="text-center text-muted px-4" style="max-width: 400px; font-size: 0.95rem;">
                                    Select an active connection on the left to review your chat history or send a dynamic message.
                                </p>
                            </div>
                        @endisset
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
