<x-app-layout>
    <div class="row g-4 justify-content-center">
        <div class="col-12 col-lg-7">
            <!-- Stories Area -->
            <div class="ig-card mb-4 border-0 shadow-sm overflow-hidden">
                <div class="ig-stories px-4 py-3">
                    <div class="ig-story" data-bs-toggle="modal" data-bs-target="#storyUploadModal">
                        <div class="ig-story-ring" style="background: hsla(240, 10%, 90%, 1);">
                            <img src="{{ auth()->user()->profile_photo ? asset('storage/'.auth()->user()->profile_photo) : 'https://ui-avatars.com/api/?name='.urlencode(auth()->user()->name) }}" alt="Your story">
                        </div>
                        <div class="ig-story-name fw-semibold mt-2">Your Story</div>
                    </div>

                    @foreach(($activeStories ?? collect()) as $userId => $stories)
                        @php
                            $story = $stories->first();
                            $storyUser = $story->user;
                        @endphp
                        <div class="ig-story" data-bs-toggle="modal" data-bs-target="#storyViewerModal" data-story-media="{{ asset('storage/'.$story->media) }}" data-story-user="{{ $storyUser->username ?? $storyUser->name }}">
                            <div class="ig-story-ring">
                                <img src="{{ $storyUser->profile_photo ? asset('storage/'.$storyUser->profile_photo) : 'https://ui-avatars.com/api/?name='.urlencode($storyUser->name) }}" alt="Story">
                            </div>
                            <div class="ig-story-name fw-medium mt-2">{{ $storyUser->username ?? $storyUser->name }}</div>
                        </div>
                    @endforeach
                </div>
            </div>

            <!-- Create Post Area -->
            <div class="ig-card mb-4 border-0 shadow-sm overflow-hidden" id="create-post">
                <div class="p-4">
                    <form action="{{ route('posts.store') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="d-flex gap-3 align-items-start">
                            <img src="{{ auth()->user()->profile_photo ? asset('storage/'.auth()->user()->profile_photo) : 'https://ui-avatars.com/api/?name='.urlencode(auth()->user()->name) }}" class="rounded-circle shadow-sm border border-2 border-white" width="48" height="48" style="object-fit: cover;" alt="Profile">
                            <div class="flex-grow-1 bg-light rounded-4 px-3 py-2 border focus-within-primary transition">
                                <input class="form-control border-0 shadow-none mb-1 bg-transparent fs-5 fw-bold" name="title" placeholder="Give it a title..." style="font-family: 'Outfit';">
                                <textarea class="form-control border-0 shadow-none bg-transparent" name="content" rows="2" placeholder="What's happening, {{ explode(' ', auth()->user()->name)[0] }}?" style="resize: none;"></textarea>
                            </div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center mt-3 pt-2">
                            <div class="d-flex align-items-center gap-2">
                                <label class="btn btn-light btn-sm ig-btn d-flex align-items-center gap-2 px-3 py-2 border-0 bg-light-subtle hover-bg-secondary-subtle">
                                    <i class="fa-solid fa-cloud-arrow-up text-primary"></i>
                                    <span class="small fw-bold">Media</span>
                                    <input type="file" name="image" class="d-none" accept="image/*">
                                </label>
                                <select name="privacy" class="form-select form-select-sm w-auto border-0 bg-light-subtle ig-btn px-3 py-2 small fw-bold">
                                    <option value="public">Public</option>
                                    <option value="friends">Circle</option>
                                    <option value="private">Private</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary btn-sm ig-btn px-4 py-2 shadow-sm">Post to Feed</button>
                        </div>
                    </form>
                </div>
            </div>

            <div id="posts-container">
                @forelse($posts as $post)
                    @include('components.post-card', ['post' => $post])
                @empty
                    <div class="ig-card p-5 text-center border-0 shadow-sm">
                        <div class="mb-3 text-muted opacity-50">
                            <i class="fa-solid fa-mountain-sun fa-4x"></i>
                        </div>
                        <h4 class="fw-bold">Quiet here...</h4>
                        <p class="text-muted small">Your feed is empty. Start following people to see their updates.</p>
                        <a href="{{ route('explore') }}" class="btn btn-primary ig-btn mt-3 px-4">Discover People</a>
                    </div>
                @endforelse
            </div>

            <div class="mt-5 mb-5 d-flex justify-content-center">
                {{ $posts->links('pagination::bootstrap-5') }}
            </div>
        </div>

        <div class="col-lg-5 col-xl-4 d-none d-lg-block">
            <div class="position-sticky" style="top: 24px;">
                <!-- User Profile Switcher -->
                <div class="ig-card p-3 mb-4 border-0 shadow-sm bg-primary text-white overflow-hidden position-relative">
                    <div class="vibrant-blob position-absolute" style="width: 200px; height: 200px; top: -50px; right: -50px; background: hsla(0, 0%, 100%, 0.1);"></div>
                    <div class="d-flex align-items-center justify-content-between position-relative z-1">
                        <div class="d-flex align-items-center gap-3">
                            <img src="{{ auth()->user()->profile_photo ? asset('storage/'.auth()->user()->profile_photo) : 'https://ui-avatars.com/api/?name='.urlencode(auth()->user()->name) }}" width="56" height="56" class="rounded-circle border border-3 border-white shadow-sm" style="object-fit: cover;" alt="Profile">
                            <div class="min-w-0">
                                <div class="fw-bold text-truncate" style="font-family: 'Outfit';">{{ auth()->user()->name }}</div>
                                <div class="small opacity-75 text-truncate">@ {{ auth()->user()->username }}</div>
                            </div>
                        </div>
                        <a href="{{ route('profile.show', auth()->user()->username ?? auth()->user()->id) }}" class="btn btn-light btn-sm rounded-pill fw-bold px-3">Profile</a>
                    </div>
                </div>

                <!-- Suggestions -->
                <div class="ig-card border-0 shadow-sm overflow-hidden">
                    <div class="p-4 py-3 border-bottom d-flex justify-content-between align-items-center">
                        <h6 class="fw-bold mb-0" style="font-family: 'Outfit';">Suggested For You</h6>
                        <a href="{{ route('explore') }}" class="small fw-bold text-decoration-none">Explore All</a>
                    </div>
                    <div class="p-4 pt-2">
                        @forelse(($suggestedUsers ?? collect()) as $sUser)
                            <div class="ig-suggestion-item py-3 id="suggestion-{{ $sUser->id }}">
                                <div class="ig-suggestion-user">
                                    <a href="{{ route('profile.show', $sUser->username ?? $sUser->id) }}" class="text-decoration-none">
                                        <img src="{{ $sUser->profile_photo ? asset('storage/'.$sUser->profile_photo) : 'https://ui-avatars.com/api/?name='.urlencode($sUser->name) }}" class="shadow-sm border border-white" width="44" height="44" alt="Avatar">
                                    </a>
                                    <div class="ig-suggestion-meta">
                                        <p class="name mb-0 fw-bold">{{ $sUser->username ?? $sUser->name }}</p>
                                        <p class="sub mb-0 text-muted x-small">New to ConnectHub</p>
                                    </div>
                                </div>
                                <button class="btn btn-link p-0 fw-bold text-primary text-decoration-none small" onclick="toggleFollowUserSimple({{ $sUser->id }}, this, 'suggestion-{{ $sUser->id }}')">Follow</button>
                            </div>
                        @empty
                            <div class="small text-muted py-4 text-center opacity-50">
                                <i class="fa-solid fa-sparkles d-block mb-2 fs-4"></i>
                                No new suggestions
                            </div>
                        @endforelse
                    </div>
                </div>
                
                <div class="mt-4 px-3 x-small text-muted opacity-50">
                    <div class="d-flex flex-wrap gap-2 mb-3">
                        <a href="#" class="text-muted text-decoration-none">About</a>
                        <a href="#" class="text-muted text-decoration-none">Support</a>
                        <a href="#" class="text-muted text-decoration-none">Press</a>
                        <a href="#" class="text-muted text-decoration-none">API</a>
                        <a href="#" class="text-muted text-decoration-none">Privacy</a>
                    </div>
                    <p class="mb-0">© 2026 CONNECTHUB FROM METAVIBE</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Modals -->
    <div class="modal fade" id="storyViewerModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content ig-card overflow-hidden bg-black border-0">
                <div class="modal-header border-0 position-absolute top-0 w-100 z-1 bg-gradient-dark">
                    <div class="fw-bold text-white small" id="storyViewerTitle" style="font-family: 'Outfit';">Story</div>
                    <button type="button" class="btn-close btn-close-white shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body p-0">
                    <img id="storyViewerImage" src="" alt="Story" class="w-100" style="max-height: 85vh; object-fit: contain;">
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="storyUploadModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content ig-card border-0 shadow-lg">
                <div class="modal-header border-0 pb-0">
                    <h5 class="fw-bold mb-0" style="font-family: 'Outfit';">Share a Moment</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="{{ route('stories.store') }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="modal-body py-4">
                        <div class="upload-zone p-5 border-2 border-dashed rounded-4 text-center bg-light transition hover-bg-light-subtle pointer">
                            <i class="fa-solid fa-cloud-arrow-up fa-3x text-primary mb-3"></i>
                            <h6 class="fw-bold mb-1">Upload Photo</h6>
                            <p class="text-muted small mb-3">Moment will last for 24 hours</p>
                            <input type="file" name="image" class="form-control" accept="image/*" required>
                        </div>
                    </div>
                    <div class="modal-footer border-0 pt-0">
                        <button type="button" class="btn btn-light ig-btn w-100 py-2 mb-2" data-bs-dismiss="modal">Forget it</button>
                        <button type="submit" class="btn btn-primary ig-btn w-100 py-3 shadow-lg">Post Moment</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    @push('scripts')
        <script>
            function toggleFollowUserSimple(userId, btn, rowId) {
                btn.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i>';
                fetch(`/u/${userId}/follow`, { method: 'POST', ...fetchConfig })
                    .then(res => res.json())
                    .then(data => {
                        if (data.status === 'followed') {
                            btn.innerText = 'Following';
                            btn.classList.remove('text-primary');
                            btn.classList.add('text-muted');
                            btn.disabled = true;
                            const row = document.getElementById(rowId);
                            if (row) row.classList.add('opacity-50');
                        } else {
                            btn.innerText = 'Follow';
                            btn.classList.add('text-primary');
                            btn.classList.remove('text-muted');
                            btn.disabled = false;
                        }
                    })
                    .catch(() => {
                        btn.innerText = 'Follow';
                    });
            }

            document.addEventListener('DOMContentLoaded', function() {
                const viewer = document.getElementById('storyViewerModal');
                if (!viewer) return;

                viewer.addEventListener('show.bs.modal', function(event) {
                    const btn = event.relatedTarget;
                    if (!btn) return;

                    const media = btn.getAttribute('data-story-media');
                    const user = btn.getAttribute('data-story-user');

                    const img = document.getElementById('storyViewerImage');
                    const title = document.getElementById('storyViewerTitle');
                    if (img) img.src = media || '';
                    if (title) title.innerText = user || 'Story';
                });
            });
        </script>
    @endpush
</x-app-layout>
