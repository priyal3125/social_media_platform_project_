<x-app-layout>
    <div class="py-5">
        <div class="discovery-header mb-5 text-center">
            <h1 class="fw-bold mb-2 hero-gradient-text" style="font-family: 'Outfit'; font-size: 3rem;">Share a Moment</h1>
            <p class="text-muted fs-5">Express your unique vibe through short, vertical videos.</p>
        </div>

        <div class="ig-card border-0 shadow-lg overflow-hidden mx-auto" style="max-width: 600px; border-radius: var(--radius-xl);">
            <div class="row g-0">
                <div class="col-md-5 bg-primary p-5 text-white d-flex flex-column justify-content-between">
                    <div>
                        <h4 class="fw-bold mb-3" style="font-family: 'Outfit';">Moment Tips</h4>
                        <ul class="list-unstyled d-flex flex-column gap-3 small opacity-90">
                            <li><i class="fa-solid fa-mobile-screen-button me-2"></i> Use vertical video (9:16)</li>
                            <li><i class="fa-solid fa-clock me-2"></i> Keep it under 60 seconds</li>
                            <li><i class="fa-solid fa-palette me-2"></i> Brighter lighting looks better</li>
                        </ul>
                    </div>
                    <div class="pt-5 mt-5">
                        <i class="fa-solid fa-clapperboard fa-3x opacity-25"></i>
                    </div>
                </div>

                <div class="col-md-7 p-5 bg-white">
                    <form action="{{ route('reels.store') }}" method="POST" enctype="multipart/form-data" id="momentUploadForm">
                        @csrf
                        <div class="mb-4">
                            <label class="form-label fw-bold small text-muted" style="font-family: 'Outfit';">Moment Caption</label>
                            <textarea class="form-control border-0 bg-light p-3 shadow-none" name="content" rows="4" placeholder="Tell the world what's happening..." style="border-radius: var(--radius-md);"></textarea>
                        </div>

                        <div class="mb-5">
                            <label class="form-label fw-bold small text-muted d-block" style="font-family: 'Outfit';">Select Video</label>
                            <div class="upload-zone p-4 border border-2 border-dashed rounded-4 text-center bg-light transition hover-bg-light-subtle pointer position-relative">
                                <i class="fa-solid fa-cloud-arrow-up fa-2x text-primary mb-2"></i>
                                <p class="mb-0 small fw-bold">Click to upload video</p>
                                <p class="mb-0 x-small text-muted">MP4, MOV up to 50MB</p>
                                <input type="file" name="video" class="position-absolute inset-0 opacity-0 pointer" accept="video/*" required onchange="updateUploadLabel(this)">
                            </div>
                            <div id="file-name-preview" class="mt-2 small text-primary fw-bold d-none text-truncate"></div>
                        </div>

                        <div class="d-flex gap-2">
                            <a href="{{ route('reels.index') }}" class="btn btn-light ig-btn flex-grow-1 py-3 border">Cancel</a>
                            <button type="submit" class="btn btn-primary ig-btn flex-grow-1 py-3 shadow-lg">Share Moment</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    @push('scripts')
        <script>
            function updateUploadLabel(input) {
                const label = document.getElementById('file-name-preview');
                if (input.files && input.files[0]) {
                    label.innerText = 'Selected: ' + input.files[0].name;
                    label.classList.remove('none');
                    label.classList.add('d-block');
                }
            }
        </script>
    @endpush
</x-app-layout>
