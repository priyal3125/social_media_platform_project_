<x-app-layout>
    <div class="ig-reels-container">
        <!-- Premium Action Header -->
        <div class="ig-card p-3 mb-5 border-0 shadow-sm bg-white" style="max-width: 450px; margin: 0 auto; border-radius: 99px;">
            <div class="d-flex align-items-center justify-content-between px-2">
                <div class="d-flex gap-2">
                    <a href="{{ route('reels.index', ['scope' => 'following']) }}" class="btn btn-sm {{ ($scope ?? 'following') === 'following' ? 'btn-primary shadow-sm' : 'btn-light border-0' }} ig-btn rounded-pill px-4" style="font-size: 0.8rem;">Following</a>
                    <a href="{{ route('reels.index', ['scope' => 'all']) }}" class="btn btn-sm {{ ($scope ?? 'following') === 'all' ? 'btn-primary shadow-sm' : 'btn-light border-0' }} ig-btn rounded-pill px-4" style="font-size: 0.8rem;">Discover</a>
                </div>
                <a href="{{ route('reels.create') }}" class="btn btn-sm btn-primary ig-btn rounded-circle p-0 d-flex align-items-center justify-content-center shadow-lg" style="width: 36px; height: 36px;">
                    <i class="fa-solid fa-plus"></i>
                </a>
            </div>
        </div>

        @if($reels->isEmpty())
            <div class="ig-card p-5 text-center border-0 shadow-sm mt-5" style="max-width: 450px; margin: 0 auto;">
                <div class="mb-4 text-muted opacity-25">
                    <i class="fa-solid fa-clapperboard fa-4x"></i>
                </div>
                <h4 class="fw-bold mb-2" style="font-family: 'Outfit';">No Moments Found</h4>
                <p class="text-muted small px-3">Follow some creators to see their latest vertical stories here.</p>
                <a href="{{ route('reels.index', ['scope' => 'all']) }}" class="btn btn-primary ig-btn mt-3 px-4 shadow-sm">Explore All</a>
            </div>
        @else
            <div class="ig-reels-track">
                @foreach($reels as $reel)
                    @php
                        $videoUrl = asset('storage/'.$reel->video);
                        $isLiked = $reel->likes->where('user_id', auth()->id())->isNotEmpty();
                        $title = $reel->title;
                        $caption = $reel->content;
                    @endphp
                    <div class="ig-reel mb-5" id="reel-{{ $reel->id }}" data-post-id="{{ $reel->id }}">
                        <div class="ig-reel-shell shadow-2xl">
                            <!-- Background Loading State -->
                            <div class="position-absolute inset-0 d-flex align-items-center justify-content-center text-white-50 opacity-25">
                                <i class="fa-solid fa-circle-notch fa-spin fa-2x"></i>
                            </div>

                            <div class="ig-reel-video">
                                @php
                                    $posterKeyword = match($reel->category ?? '') {
                                        'Travel'  => 'travel,adventure',
                                        'Food'    => 'food,restaurant',
                                        'Nature'  => 'nature,landscape',
                                        'Art'     => 'art,creative',
                                        'Fashion' => 'fashion,model',
                                        'Tech'    => 'technology,innovation',
                                        'People'  => 'people,lifestyle',
                                        default   => 'moments,lifestyle',
                                    };
                                    $posterUrl = 'https://loremflickr.com/450/800/' . urlencode($posterKeyword) . '?lock=' . $reel->id;
                                @endphp
                                <video class="ig-reel-player"
                                       src="{{ $videoUrl }}"
                                       poster="{{ $posterUrl }}"
                                       playsinline muted loop
                                       preload="none"></video>
                            </div>

                            <!-- Mobile-style UI Overlay -->
                            <div class="ig-reel-ui">
                                <div class="ig-reel-meta mb-3">
                                    <div class="d-flex align-items-center gap-3 mb-3">
                                        <div class="position-relative">
                                            <img src="{{ $reel->user->profile_photo ? asset('storage/'.$reel->user->profile_photo) : 'https://ui-avatars.com/api/?name='.urlencode($reel->user->name) }}" width="44" height="44" class="rounded-circle border border-2 border-white shadow-sm" style="object-fit: cover;" alt="Profile">
                                            <span class="position-absolute bottom-0 end-0 bg-success rounded-circle border border-2 border-white" style="width: 12px; height: 12px;"></span>
                                        </div>
                                        <div>
                                            <a href="{{ route('profile.show', $reel->user->username ?? $reel->user->id) }}" class="text-white text-decoration-none fw-bold" style="font-family: 'Outfit';">{{ $reel->user->username ?? $reel->user->name }}</a>
                                            <div class="x-small text-white-50 fw-medium">ConnectHub Creator</div>
                                        </div>
                                    </div>
                                    
                                    @if($title || $caption)
                                        <div class="small fw-medium lh-base text-white truncate-2-lines" style="text-shadow: 0 1px 2px rgba(0,0,0,0.5);">
                                            {{ $title ?: $caption }}
                                        </div>
                                    @endif
                                </div>

                                <div class="ig-reel-actions">
                                    <div class="text-center mb-3">
                                        <button class="btn p-0 border-0 bg-transparent like-btn {{ $isLiked ? 'text-danger' : 'text-white' }} drop-shadow-sm scale-on-click" id="like-btn-{{ $reel->id }}" onclick="toggleLike({{ $reel->id }})" style="font-size: 2rem;">
                                            <i class="fa-{{ $isLiked ? 'solid' : 'regular' }} fa-heart" id="like-icon-{{ $reel->id }}"></i>
                                        </button>
                                        <div class="x-small fw-bold text-white mt-1" id="likes-count-{{ $reel->id }}">{{ $reel->likes->count() }}</div>
                                    </div>

                                    <div class="text-center mb-3">
                                        <button class="btn p-0 border-0 bg-transparent text-white drop-shadow-sm" onclick="toggleComments({{ $reel->id }})" style="font-size: 1.8rem;">
                                            <i class="fa-regular fa-comment"></i>
                                        </button>
                                        <div class="x-small fw-bold text-white mt-1">{{ $reel->comments->count() }}</div>
                                    </div>

                                    <div class="text-center">
                                        <button class="btn p-0 border-0 bg-transparent text-white drop-shadow-sm" style="font-size: 1.8rem;">
                                            <i class="fa-solid fa-paper-plane"></i>
                                        </button>
                                        <div class="x-small fw-bold text-white mt-1">Share</div>
                                    </div>
                                </div>
                            </div>

                            <!-- Swipeable-style Comments Drawer -->
                            <div class="ig-reel-comments" id="comments-section-{{ $reel->id }}" style="height: 60%;">
                                <div class="px-4 py-3 border-bottom d-flex align-items-center justify-content-between">
                                    <h6 class="fw-bold mb-0" style="font-family: 'Outfit';">Moment Details</h6>
                                    <button class="btn-close btn-close-sm shadow-none" onclick="toggleComments({{ $reel->id }})"></button>
                                </div>
                                <div class="p-4" style="height: calc(100% - 100px); overflow-y: auto;">
                                    <div class="mb-4">
                                        <p class="small text-muted mb-0 lh-base">{{ $reel->content ?? $reel->title }}</p>
                                    </div>
                                    <hr class="opacity-10 text-muted">
                                    <div id="comments-list-{{ $reel->id }}" class="mb-3">
                                        @forelse($reel->comments->sortByDesc('created_at')->take(30) as $comment)
                                            <div class="d-flex align-items-start gap-2 mb-3">
                                                <img src="{{ $comment->user->profile_photo ? asset('storage/'.$comment->user->profile_photo) : 'https://ui-avatars.com/api/?name='.urlencode($comment->user->name) }}" width="30" height="30" class="rounded-circle border" style="object-fit: cover;">
                                                <div class="bg-light p-2 rounded-3 flex-grow-1" style="font-size: 0.8rem;">
                                                    <a href="{{ route('profile.show', $comment->user->username ?? $comment->user->id) }}" class="text-decoration-none text-dark fw-bold me-1">{{ $comment->user->username ?? $comment->user->name }}</a>
                                                    {{ $comment->comment }}
                                                </div>
                                            </div>
                                        @empty
                                            <div class="text-center text-muted py-4 small opacity-50">Be the first to comment</div>
                                        @endforelse
                                    </div>
                                </div>
                                <div class="p-3 border-top bg-white">
                                    <div class="d-flex align-items-center bg-light rounded-pill px-3 py-1">
                                        <input type="text" class="form-control bg-transparent border-0 shadow-none py-2" id="comment-input-{{ $reel->id }}" placeholder="Express yourself..." onkeypress="handleCommentSubmit(event, {{ $reel->id }})" style="font-size: 0.9rem;">
                                        <button class="btn btn-link text-primary fw-bold text-decoration-none p-0 ps-2" onclick="submitCommentBtn({{ $reel->id }})" style="font-size: 0.9rem;">Post</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        @endif
    </div>

    @push('scripts')
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const players = Array.from(document.querySelectorAll('.ig-reel-player'));
                if (players.length === 0) return;

                const playOnly = (active) => {
                    players.forEach((p) => {
                        if (p === active) {
                            p.play().catch(() => {});
                        } else {
                            p.pause();
                        }
                    });
                };

                const viewed = new Set();
                const observer = new IntersectionObserver((entries) => {
                    const visible = entries
                        .filter(e => e.isIntersecting)
                        .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];

                    if (!visible) return;
                    const player = visible.target.querySelector('.ig-reel-player');
                    if (player) playOnly(player);

                    const postId = visible.target.getAttribute('data-post-id');
                    if (postId && !viewed.has(postId)) {
                        viewed.add(postId);
                        fetch(`/posts/${postId}/view`, { method: 'POST', ...fetchConfig })
                            .catch(() => {});
                    }
                }, { threshold: [0.5, 0.8] });

                document.querySelectorAll('.ig-reel').forEach((el) => observer.observe(el));

                document.querySelectorAll('.ig-reel-video').forEach((wrap) => {
                    wrap.addEventListener('click', function() {
                        const player = wrap.querySelector('video');
                        if (!player) return;
                        if (player.paused) {
                            player.play().catch(() => {});
                        } else {
                            player.pause();
                        }
                    });
                });
            });
        </script>
    @endpush
</x-app-layout>
