<x-app-layout>
    @php
        $getPostImageUrl = function ($post) {
            if ($post->image) {
                return asset('storage/'.$post->image);
            }
            // Use LoremFlickr with a unique lock for every post ID
            // This guarantees uniqueness while ensuring same ID always gets same high-quality human photo
            return "https://loremflickr.com/800/800/people,person,portrait,face?lock=" . $post->id;
        };
    @endphp

    <div class="ig-card p-4 mb-4">
        <div class="row align-items-center g-4">
            <div class="col-auto">
                <img src="{{ $user->profile_photo ? asset('storage/'.$user->profile_photo) : 'https://ui-avatars.com/api/?name='.urlencode($user->name) }}" class="rounded-circle border" width="140" height="140" style="object-fit: cover;" alt="Profile">
            </div>
            <div class="col">
                <div class="d-flex align-items-center flex-wrap gap-2">
                    <div class="fs-4 fw-semibold">{{ $user->username ?? $user->name }}</div>

                    @if(auth()->id() === $user->id)
                        <a href="{{ route('profile.edit') }}" class="btn btn-light ig-btn px-3">Edit Profile</a>
                    @else
                        @php $isFollowing = auth()->user()->following()->where('following_id', $user->id)->exists(); @endphp
                        <button class="btn {{ $isFollowing ? 'btn-light' : 'btn-primary' }} ig-btn px-3" id="follow-btn-{{ $user->id }}" onclick="toggleFollowUser({{ $user->id }}, this)">
                            {{ $isFollowing ? 'Following' : 'Follow' }}
                        </button>
                        <a href="{{ route('messages.chat', $user->id) }}" class="btn btn-light ig-btn px-3">Message</a>
                    @endif
                </div>

                <div class="d-flex gap-4 mt-3 flex-wrap">
                    <div><span class="fw-semibold">{{ ($postsCount ?? 0) + ($reelsCount ?? 0) }}</span> posts</div>
                    <div><span class="fw-semibold" id="followers-count-{{ $user->id }}">{{ $user->followers()->count() }}</span> followers</div>
                    <div><span class="fw-semibold">{{ $user->following()->count() }}</span> following</div>
                </div>

                <div class="mt-3">
                    <div class="fw-semibold">{{ $user->name }}</div>
                    @if($user->bio)
                        <div style="white-space: pre-line;">{{ $user->bio }}</div>
                    @endif
                    <div class="small ig-muted mt-2">Joined {{ $user->created_at->format('F Y') }}</div>
                </div>
            </div>
        </div>
    </div>

    <div class="ig-card p-2 mb-3">
        <div class="d-flex align-items-center gap-2">
            <a href="{{ route('profile.show', ($user->username ?? $user->id)) }}" class="btn btn-sm {{ ($tab ?? 'posts') === 'posts' ? 'btn-primary' : 'btn-light' }} ig-btn px-3">Posts ({{ $postsCount ?? 0 }})</a>
            <a href="{{ route('profile.show', ($user->username ?? $user->id)) }}?tab=reels" class="btn btn-sm {{ ($tab ?? 'posts') === 'reels' ? 'btn-primary' : 'btn-light' }} ig-btn px-3">Reels ({{ $reelsCount ?? 0 }})</a>
        </div>
    </div>

    @if($posts->isEmpty())
        <div class="ig-card p-5 text-center ig-muted">
            <div class="mb-3">
                <i class="fa-solid {{ ($tab ?? 'posts') === 'reels' ? 'fa-film' : 'fa-camera' }} fa-3x"></i>
            </div>
            <div class="fw-semibold">No {{ ($tab ?? 'posts') === 'reels' ? 'reels' : 'posts' }} yet</div>
        </div>
    @else
        <div class="ig-grid mb-4">
            @foreach($posts as $post)
                @php
                    $imgUrl = $getPostImageUrl($post);
                    $gridImg = $imgUrl;
                    $modalImg = $imgUrl;
                    
                    $videoUrl = $post->video ? asset('storage/'.$post->video) : '';
                    $profile = $user->profile_photo ? asset('storage/'.$user->profile_photo) : 'https://ui-avatars.com/api/?name='.urlencode($user->name);
                    $fileName = $post->video ? basename($post->video) : ($post->image ? basename($post->image) : ('ai-' . $post->id . '.png'));
                    $viewsCount = $post->views_count ?? 0;
                    $overlayTitle = $post->title ?: ($user->username ?? $user->name);
                @endphp
                <div class="ig-grid-item pointer" 
                     style="cursor: pointer;"
                     data-trigger-post-modal
                     data-post-id="{{ $post->id }}" 
                     data-post-image-grid="{{ $gridImg }}" 
                     data-post-image-modal="{{ $modalImg }}" 
                     data-post-video="{{ $videoUrl }}" 
                     data-post-profile="{{ $profile }}" 
                     data-post-user="{{ $user->username ?? $user->name }}" 
                     data-post-filename="{{ $fileName }}" 
                     data-post-views="{{ $viewsCount }}" 
                     data-post-caption="{{ e($post->content ?? '') }}" 
                     data-post-title="{{ e($post->title ?? '') }}">
                    @if($videoUrl)
                        <video src="{{ $videoUrl }}" muted playsinline preload="metadata" style="position:absolute; inset:0; width:100%; height:100%; object-fit:cover;"></video>
                        <div style="position:absolute; top:8px; right:8px; color:#fff; text-shadow:0 1px 2px rgba(0,0,0,0.45); font-size:1.1rem;">
                            <i class="fa-solid fa-film"></i>
                        </div>
                    @else
                            <img src="{{ $gridImg }}" 
                                 class="w-100 h-100" 
                                 style="object-fit: cover;" 
                                 alt="Post"
                                 onerror="this.onerror=null; this.src='https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=800&q=80';">
                    @endif

                    <div class="ig-grid-overlay">
                        <div class="ig-grid-user">{{ $overlayTitle }}</div>
                        <div class="ig-grid-meta">
                            <div class="line">
                                <span class="filename">{{ $fileName }}</span>
                                <span><i class="fa-regular fa-eye"></i> <span id="profile-views-{{ $post->id }}">{{ $viewsCount }}</span></span>
                            </div>
                            @if($post->title)
                                <div class="caption">{{ $post->title }}</div>
                            @elseif($post->content)
                                <div class="caption">{{ $post->content }}</div>
                            @endif
                        </div>
                    </div>
                </div>
            @endforeach
        </div>

        <div class="mt-4">
            {{ $posts->links('pagination::bootstrap-5') }}
        </div>
    @endif

    {{-- Shared modal is included in app.blade.php --}}
    @push('scripts')
    <script>
        async function toggleFollowUser(userId, btn) {
            try {
                const response = await fetch(`/u/${userId}/follow`, {
                    method: 'POST',
                    ...fetchConfig
                });
                if (response.ok) {
                    const data = await response.json();
                    const countSpan = document.getElementById(`followers-count-${userId}`);
                    countSpan.innerText = data.followers_count;
                    
                    if (data.status === 'followed') {
                        btn.innerText = 'Following';
                        btn.classList.remove('btn-primary');
                        btn.classList.add('btn-light');
                    } else {
                        btn.innerText = 'Follow';
                        btn.classList.remove('btn-light');
                        btn.classList.add('btn-primary');
                    }
                }
            } catch (error) {
                console.error(error);
            }
        }
    </script>
    @endpush
</x-app-layout>
