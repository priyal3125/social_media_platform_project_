<!-- Shared Premium Post Modal -->
<div class="modal fade" id="postDetailModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl" style="max-width: 1050px;">
        <div class="modal-content ig-card border-0 shadow-2xl overflow-hidden" 
             style="border-radius: var(--radius-xl); background: #fff;">
            <div class="row g-0">
                <!-- Media Section -->
                <div class="col-lg-7 bg-black d-flex align-items-center justify-content-center position-relative overflow-hidden" 
                     style="min-height: 400px; background: #000;">
                    <img id="modalPostImage" src="" alt="Post" class="w-100 h-100" style="object-fit: cover; max-height: 80vh;"
                         onerror="this.onerror=null; this.src='https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=800&q=80';">
                    <video id="modalPostVideo" src="" class="w-100 h-100" style="object-fit: contain; display: none; max-height: 80vh;" controls playsinline></video>
                </div>
                
                <!-- Details Section -->
                <div class="col-lg-5 bg-white d-flex flex-column border-start" style="min-height: 500px;">
                    <!-- User Header -->
                    <div class="p-3 d-flex align-items-center gap-3 border-bottom flex-shrink-0">
                        <img id="modalPostProfile" src="" width="40" height="40" class="rounded-circle border border-2 border-primary-light" style="object-fit: cover;" alt="Profile"
                             onerror="this.onerror=null; this.src='https://ui-avatars.com/api/?name=User';">
                        <div class="min-w-0">
                            <div class="fw-bold text-dark text-truncate small" id="modalPostUser" style="font-family: 'Outfit';"></div>
                            <div class="x-small text-muted mb-0"><i class="fa-solid fa-location-dot me-1"></i> Exploring World</div>
                        </div>
                        <button type="button" class="btn-close ms-auto shadow-none small" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    <!-- Content & Comments Area -->
                    <div class="p-4 flex-grow-1 overflow-y-auto custom-scrollbar" style="max-height: 400px;">
                        <!-- Stats Badge -->
                        <div class="d-flex align-items-center gap-2 mb-3">
                            <div class="badge bg-light text-primary py-2 px-3 rounded-pill fw-bold" style="font-size: 0.7rem;">
                                <i class="fa-solid fa-eye me-1"></i> <span id="modalPostViews"></span> Views
                            </div>
                            <div class="badge bg-light text-muted py-2 px-3 rounded-pill" style="font-size: 0.65rem;">
                                <span id="modalPostFileName"></span>
                            </div>
                        </div>

                        <!-- Caption -->
                        <div class="fs-6 text-dark opacity-85 mb-4" id="modalPostCaption" style="white-space: pre-line; line-height: 1.5; font-size: 0.95rem;"></div>
                        
                        <div class="mt-4 border-top pt-4">
                            <h6 class="fw-bold mb-3 small opacity-50 text-uppercase tracking-wider" style="font-size: 0.7rem;">Quick Actions</h6>
                            <div class="d-flex gap-2">
                                <button class="btn btn-primary ig-btn flex-grow-1 py-2 shadow-sm rounded-3">
                                    <i class="fa-solid fa-heart me-2"></i> Like
                                </button>
                                <button class="btn btn-light ig-btn flex-grow-1 py-2 border shadow-sm rounded-3">
                                    <i class="fa-solid fa-paper-plane me-2"></i> Share
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.custom-scrollbar::-webkit-scrollbar { width: 4px; }
.custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
.custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(0,0,0,0.1); border-radius: 10px; }
.overflow-y-auto { overflow-y: auto !important; }
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const modal = document.getElementById('postDetailModal');
    if (!modal) return;

    const fallbackImg = 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=800&q=80';

    // Use event delegation for dynamically added posts or multiple triggers
    document.addEventListener('click', function(e) {
        let trigger = e.target.closest('[data-trigger-post-modal]');
        if (trigger) {
            e.preventDefault();
            populateModal(trigger);
            const bsModal = new bootstrap.Modal(modal);
            bsModal.show();
        }
    });

    function populateModal(item) {
        let img = item.getAttribute('data-post-image-modal') || item.getAttribute('data-post-image-grid') || '';
        const video = item.getAttribute('data-post-video') || '';
        const profile = item.getAttribute('data-post-profile') || '';
        const user = item.getAttribute('data-post-user') || '';
        const filename = item.getAttribute('data-post-filename') || '';
        const views = item.getAttribute('data-post-views') || '0';
        const title = item.getAttribute('data-post-title') || '';
        const caption = item.getAttribute('data-post-caption') || '';

        const imgEl = document.getElementById('modalPostImage');
        const videoEl = document.getElementById('modalPostVideo');
        const profileEl = document.getElementById('modalPostProfile');
        const userEl = document.getElementById('modalPostUser');
        const fileEl = document.getElementById('modalPostFileName');
        const viewsEl = document.getElementById('modalPostViews');
        const captionEl = document.getElementById('modalPostCaption');

        if (video && videoEl && imgEl) {
            videoEl.src = video;
            videoEl.style.display = 'block';
            imgEl.style.display = 'none';
        } else if (imgEl) {
            if (videoEl) {
                videoEl.pause();
                videoEl.removeAttribute('src');
                videoEl.load();
                videoEl.style.display = 'none';
            }
            // If no image provided, use fallback immediately
            imgEl.src = img || fallbackImg;
            imgEl.style.display = 'block';
        }

        if (profileEl) profileEl.src = profile || 'https://ui-avatars.com/api/?name=' + encodeURIComponent(user);
        if (userEl) userEl.innerText = user;
        if (fileEl) fileEl.innerText = filename;
        if (viewsEl) viewsEl.innerText = views;
        
        let fullCaption = title;
        if (caption) {
            fullCaption += (title ? '\n\n' : '') + caption;
        }
        if (captionEl) captionEl.innerText = fullCaption || 'No description provided.';
        
        // Track View
        const postId = item.getAttribute('data-post-id');
        if (postId) {
            fetch(`/posts/${postId}/view`, { method: 'POST', ...fetchConfig })
                .then(res => res.ok ? res.json() : null)
                .then(data => {
                    if (data && viewsEl) viewsEl.innerText = data.views_count;
                });
        }
    }

    modal.addEventListener('hidden.bs.modal', function() {
        const videoEl = document.getElementById('modalPostVideo');
        if (videoEl) {
            videoEl.pause();
            videoEl.removeAttribute('src');
            videoEl.load();
        }
    });
});
</script>
