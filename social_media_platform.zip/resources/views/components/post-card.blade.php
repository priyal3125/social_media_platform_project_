<div class="card ig-card mb-5 post-card border-0" id="post-{{ $post->id }}" data-post-id="{{ $post->id }}">
    @php
        $title = $post->title;
        $caption = $post->content;
        $user = $post->user->name ?? 'someone';
        
        // Use LoremFlickr with a unique lock for every post ID
        $imgUrl = $post->image ? asset('storage/'.$post->image) : "https://loremflickr.com/800/800/people,person,portrait,face?lock=" . $post->id;
        $mediaUrl = $imgUrl;
        $videoUrl = $post->video ? asset('storage/'.$post->video) : null;

        // Check if the current user has saved this post
        $isSaved = \App\Models\SavedPost::where('user_id', auth()->id())
                        ->where('post_id', $post->id)
                        ->exists();
    @endphp
    
    <!-- Premium Header -->
    <div class="card-header bg-white border-0 d-flex justify-content-between align-items-center py-3 px-3">
        <div class="d-flex align-items-center">
            <div class="ig-story-ring p-0 me-3" style="width: 44px; height: 44px; background: linear-gradient(135deg, var(--primary), var(--accent));">
                <a href="{{ route('profile.show', $post->user->username ?? $post->user->id) }}">
                    <img src="{{ $post->user->profile_photo ? asset('storage/'.$post->user->profile_photo) : 'https://ui-avatars.com/api/?name='.urlencode($post->user->name) }}" class="rounded-circle border border-2 border-white" width="40" height="40" style="object-fit: cover;" alt="Profile">
                </a>
            </div>
            <div>
                <a href="{{ route('profile.show', $post->user->username ?? $post->user->id) }}" class="text-decoration-none text-dark fw-bold mb-0 small d-block" style="font-family: 'Outfit';">{{ $post->user->username ?? $post->user->name }}</a>
                <div class="d-flex align-items-center gap-1">
                    <small class="text-muted" style="font-size: 0.7rem;">{{ $post->created_at->diffForHumans() }}</small>
                    <span class="text-muted" style="font-size: 0.7rem;">•</span>
                    <i class="fa-solid fa-earth-americas text-muted" style="font-size: 0.65rem;"></i>
                </div>
            </div>
        </div>
        
        <div class="dropdown">
            <button class="btn btn-link text-muted text-decoration-none p-2 rounded-circle hover-bg-light" type="button" data-bs-toggle="dropdown">
                <i class="fa-solid fa-ellipsis-vertical"></i>
            </button>
            <ul class="dropdown-menu dropdown-menu-end shadow-lg border-0 rounded-4 p-2">
                <li>
                    <button class="dropdown-item rounded-3 small p-2"
                            onclick="toggleSave({{ $post->id }}, document.getElementById('save-btn-{{ $post->id }}'))">
                        <i class="fa-regular fa-bookmark me-2" id="dropdown-save-icon-{{ $post->id }}"></i>
                        <span id="dropdown-save-text-{{ $post->id }}">{{ $isSaved ? 'Unsave' : 'Save Post' }}</span>
                    </button>
                </li>
                <li><a class="dropdown-item rounded-3 small p-2" href="#"><i class="fa-regular fa-bell me-2"></i>Turn on Notifications</a></li>
                @if(auth()->id() == $post->user_id || (auth()->user()->is_admin ?? false))
                <li><hr class="dropdown-divider opacity-50"></li>
                <li>
                    <form action="{{ route('posts.destroy', $post->id) }}" method="POST" onsubmit="return confirm('Are you sure you want to delete this post?');">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="dropdown-item rounded-3 small p-2 text-danger"><i class="fa-regular fa-trash-can me-2"></i>Delete</button>
                    </form>
                </li>
                @endif
            </ul>
        </div>
    </div>

    <!-- Stunning Media Area -->
    <div class="post-media-container position-relative bg-light pointer" 
         style="min-height: 300px; cursor: pointer;"
         data-trigger-post-modal
         data-post-id="{{ $post->id }}"
         data-post-image-modal="{{ $mediaUrl }}"
         data-post-video="{{ $videoUrl }}"
         data-post-profile="{{ $post->user->profile_photo ? asset('storage/'.$post->user->profile_photo) : 'https://ui-avatars.com/api/?name='.urlencode($post->user->name) }}"
         data-post-user="{{ $post->user->username ?? $post->user->name }}"
         data-post-filename="{{ $videoUrl ? basename($videoUrl) : ($post->image ? basename($post->image) : 'ai-generated.png') }}"
         data-post-views="{{ $post->views_count ?? 0 }}"
         data-post-title="{{ e($post->title ?? '') }}"
         data-post-caption="{{ e($post->content ?? '') }}">
        @if($videoUrl)
            <div class="bg-black d-flex align-items-center justify-content-center" style="max-height: 720px; aspect-ratio: 4/5;">
                <video src="{{ $videoUrl }}" class="w-100 h-100" style="object-fit: contain;" muted playsinline></video>
                <div class="position-absolute top-50 start-50 translate-middle text-white opacity-50">
                    <i class="fa-solid fa-play fa-3x"></i>
                </div>
            </div>
        @else
            <img src="{{ $mediaUrl }}" 
                 class="w-100 h-auto" 
                 alt="Post Image" 
                 style="object-fit: cover; max-height: 800px;"
                 onerror="this.onerror=null; this.src='https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=800&q=80';">
        @endif
    </div>

    <!-- Refined Interaction Row -->
    <div class="card-body p-4 pt-3">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div class="d-flex gap-4">
                @php $isLiked = $post->likes->where('user_id', auth()->id())->isNotEmpty(); @endphp
                <button class="btn p-0 border-0 bg-transparent like-btn {{ $isLiked ? 'text-danger' : 'text-dark' }}" onclick="toggleLike({{ $post->id }})" style="font-size: 1.5rem; transition: transform 0.2s cubic-bezier(0.175, 0.885, 0.32, 1.275);">
                    <i class="fa-{{ $isLiked ? 'solid' : 'regular' }} fa-heart scale-hover" id="like-icon-{{ $post->id }}"></i>
                </button>
                
                <button class="btn p-0 border-0 bg-transparent text-dark hov-grow" onclick="toggleComments({{ $post->id }})" style="font-size: 1.5rem;">
                    <i class="fa-regular fa-comment scale-hover"></i>
                </button>
                
                <button class="btn p-0 border-0 bg-transparent text-dark hov-grow"
                        onclick="sharePost({{ $post->id }}, '{{ addslashes($post->title ?: $post->content) }}')"
                        title="Share"
                        style="font-size: 1.5rem;">
                    <i class="fa-regular fa-paper-plane scale-hover" id="share-icon-{{ $post->id }}"></i>
                </button>
            </div>
            
            <button class="btn p-0 border-0 bg-transparent hov-grow save-btn"
                    id="save-btn-{{ $post->id }}"
                    onclick="toggleSave({{ $post->id }}, this)"
                    title="{{ $isSaved ? 'Unsave' : 'Save' }}"
                    style="font-size: 1.5rem; color: {{ $isSaved ? 'var(--primary)' : 'inherit' }};">
                <i class="fa-{{ $isSaved ? 'solid' : 'regular' }} fa-bookmark scale-hover" id="save-icon-{{ $post->id }}"></i>
            </button>
        </div>

        <div class="mb-3">
            <div class="d-flex align-items-center gap-2">
                <div class="avatar-stack d-flex">
                    <img src="https://i.pravatar.cc/150?u=1" class="rounded-circle border border-2 border-white shadow-sm" width="20" height="20" style="margin-right: -8px; z-index: 3;">
                    <img src="https://i.pravatar.cc/150?u=2" class="rounded-circle border border-2 border-white shadow-sm" width="20" height="20" style="margin-right: -8px; z-index: 2;">
                    <img src="https://i.pravatar.cc/150?u=3" class="rounded-circle border border-2 border-white shadow-sm" width="20" height="20" style="z-index: 1;">
                </div>
                <span class="fw-bold small" id="likes-count-{{ $post->id }}">
                    {{ number_format($post->likes->count()) }} likes
                </span>
            </div>
        </div>

        @if($title || $caption)
            <div class="mb-3">
                <div class="small">
                    <span class="fw-bold me-2" style="font-family: 'Outfit';">{{ $post->user->username ?? $post->user->name }}</span>
                    <span class="text-secondary" style="white-space: pre-line; line-height: 1.6;">{{ $title ?: $caption }}</span>
                </div>
                @if($title && $caption)
                    <div class="mt-2 text-secondary small opacity-75" style="white-space: pre-line; line-height: 1.6;">{{ $caption }}</div>
                @endif
            </div>
        @endif

        <div class="comments-section" id="comments-section-{{ $post->id }}">
            <div id="comments-list-{{ $post->id }}" class="mb-3">
                @foreach($post->comments->sortByDesc('created_at')->take(2) as $comment)
                    <div class="d-flex align-items-start mb-2 small">
                        <span class="fw-bold me-2" style="font-family: 'Outfit';">{{ $comment->user->username ?? $comment->user->name }}</span>
                        <span class="text-secondary">{{ $comment->comment }}</span>
                    </div>
                @endforeach
            </div>

            @if($post->comments->count() > 2)
                <a href="javascript:void(0)" onclick="toggleComments({{ $post->id }})" class="text-decoration-none text-muted small fw-semibold d-block mb-3 opacity-75">
                    View all {{ $post->comments->count() }} comments
                </a>
            @endif

            <div class="comment-input-wrapper position-relative">
                <div class="d-flex align-items-center bg-light rounded-pill px-3 py-2 border border-transparent focus-within-primary">
                    <i class="fa-regular fa-face-smile text-muted me-2"></i>
                    <input type="text" class="form-control border-0 bg-transparent p-0 shadow-none small flex-grow-1" id="comment-input-{{ $post->id }}" placeholder="Add a comment..." onkeypress="handleCommentSubmit(event, {{ $post->id }})" style="height: auto;">
                    <button class="btn btn-link text-primary fw-bold text-decoration-none p-0 ps-2 small" onclick="submitCommentBtn({{ $post->id }})" style="box-shadow: none;">Post</button>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .scale-hover:hover { transform: scale(1.1); }
    .focus-within-primary:focus-within {
        border-color: var(--primary) !important;
        background: white !important;
        box-shadow: 0 0 0 4px hsla(250, 100%, 62%, 0.1);
    }
    .hover-bg-light:hover { background: rgba(0,0,0,0.05); }
    .post-card { overflow: visible !important; }
    .save-btn.pop { animation: savePop .35s cubic-bezier(.36,.07,.19,.97); }
    @keyframes savePop {
        0%   { transform: scale(1); }
        40%  { transform: scale(1.4); }
        70%  { transform: scale(.85); }
        100% { transform: scale(1); }
    }
</style>

<script>
function sharePost(postId, caption) {
    const url = window.location.origin + '/posts/' + postId;
    const text = caption || 'Check out this post!';

    if (navigator.share) {
        navigator.share({ title: text, url: url }).catch(() => {});
    } else {
        navigator.clipboard.writeText(url).then(() => {
            const icon = document.getElementById('share-icon-' + postId);
            if (icon) {
                icon.classList.replace('fa-paper-plane', 'fa-check');
                icon.style.color = '#22c55e';
                setTimeout(() => {
                    icon.classList.replace('fa-check', 'fa-paper-plane');
                    icon.style.color = '';
                }, 1800);
            }
        }).catch(() => { alert('Link: ' + url); });
    }
}

function toggleSave(postId, btnEl) {
    fetch('/posts/' + postId + '/save', {
        method: 'POST',
        ...window.fetchConfig
    })
    .then(r => r.json())
    .then(data => {
        const icon    = document.getElementById('save-icon-' + postId);
        const btn     = document.getElementById('save-btn-' + postId);
        const ddIcon  = document.getElementById('dropdown-save-icon-' + postId);
        const ddText  = document.getElementById('dropdown-save-text-' + postId);
        const saved   = data.status === 'saved';

        // Update main button icon + color
        if (icon) {
            icon.classList.toggle('fa-solid', saved);
            icon.classList.toggle('fa-regular', !saved);
        }
        if (btn) {
            btn.style.color = saved ? 'var(--primary, #6c63ff)' : '';
            btn.title = saved ? 'Unsave' : 'Save';
            btn.classList.add('pop');
            setTimeout(() => btn.classList.remove('pop'), 400);
        }

        // Update dropdown item
        if (ddIcon) {
            ddIcon.classList.toggle('fa-solid', saved);
            ddIcon.classList.toggle('fa-regular', !saved);
        }
        if (ddText) ddText.textContent = saved ? 'Unsave' : 'Save Post';
    })
    .catch(err => console.error('Save failed:', err));
}
</script>
