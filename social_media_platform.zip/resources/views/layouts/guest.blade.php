<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>{{ config('app.name', 'ConnectHub') }} — Experience the Next Level</title>

        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
        <link rel="stylesheet" href="{{ asset('css/instagram.css') }}">

        <style>
            .auth-split-layout {
                min-height: 100vh;
                display: flex;
            }

            .auth-hero-pane {
                flex: 1.2;
                background: var(--secondary);
                background-image: 
                    radial-gradient(circle at 20% 30%, hsla(250, 100%, 65%, 0.4) 0%, transparent 60%),
                    radial-gradient(circle at 80% 70%, hsla(330, 100%, 65%, 0.3) 0%, transparent 60%);
                display: flex;
                flex-direction: column;
                justify-content: center;
                padding: 80px;
                color: white;
                position: relative;
                overflow: hidden;
            }

            .auth-hero-pane::before {
                content: '';
                position: absolute;
                inset: 0;
                background: url('https://www.transparenttextures.com/patterns/cubes.png');
                opacity: 0.1;
            }

            .hero-title {
                font-family: 'Outfit', sans-serif;
                font-weight: 800;
                font-size: clamp(3rem, 5vw, 4.5rem);
                line-height: 1.1;
                margin-bottom: 24px;
                z-index: 1;
            }

            .hero-subtitle {
                font-size: 1.25rem;
                opacity: 0.8;
                max-width: 480px;
                z-index: 1;
                line-height: 1.6;
            }

            .auth-form-pane {
                flex: 0.8;
                display: flex;
                align-items: center;
                justify-content: center;
                background: var(--bg-app);
                padding: 40px;
            }

            .premium-card {
                background: white;
                border-radius: var(--radius-xl);
                box-shadow: var(--shadow-lg);
                padding: 48px;
                width: 100%;
                max-width: 480px;
                border: 1px solid var(--border);
                transition: var(--transition);
            }

            .auth-badge {
                display: inline-block;
                padding: 6px 16px;
                background: hsla(250, 100%, 65%, 0.1);
                color: var(--primary);
                font-weight: 700;
                font-size: 0.75rem;
                text-transform: uppercase;
                letter-spacing: 1.5px;
                border-radius: 99px;
                margin-bottom: 24px;
            }

            @media (max-width: 991.98px) {
                .auth-hero-pane { display: none; }
                .auth-form-pane { flex: 1; padding: 20px; }
            }
        </style>
    </head>
    <body>
        <div class="auth-split-layout">
            <div class="auth-hero-pane">
                <div class="mb-5">
                    <a href="/" class="text-white text-decoration-none fs-2 fw-bold" style="font-family: 'Outfit';">
                        <i class="fa-solid fa-earth-americas me-2"></i> ConnectHub
                    </a>
                </div>
                <h1 class="hero-title">Connect <br> Without <br> <span style="color: var(--accent);">Boundaries.</span></h1>
                <p class="hero-subtitle">The next evolution of social connection. Minimal, elegant, and designed for meaningful daily interaction.</p>
                
                <div class="mt-auto d-flex gap-4 opacity-50 small">
                    <span>Privacy First</span>
                    <span>No Algorithms</span>
                    <span>Pure Experience</span>
                </div>
            </div>

            <div class="auth-form-pane">
                <div class="premium-card">
                    {{ $slot }}
                </div>
            </div>
        </div>
        
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    </body>
</html>
