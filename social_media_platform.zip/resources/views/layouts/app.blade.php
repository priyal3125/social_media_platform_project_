<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" data-bs-theme="light">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>{{ config('app.name', 'ConnectHub') }}</title>

        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
        <link rel="stylesheet" href="{{ asset('css/instagram.css') }}">
    </head>
    <body>
        <div class="ig-app">
            @include('layouts.ig-sidebar')

            <div class="ig-content">
                <main class="ig-container">
                    @isset($header)
                        <div class="mb-3">
                            {{ $header }}
                        </div>
                    @endisset
                    {{ $slot }}
                </main>
            </div>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
        
        <script>
            // Global Fetch Setup with CSRF
            window.csrf_token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
            
            const fetchConfig = {
                headers: {
                    'X-CSRF-TOKEN': window.csrf_token,
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                }
            };

            // Toggle Comments Section
            function toggleComments(postId) {
                const commentsSection = document.getElementById(`comments-section-${postId}`);
                if (getComputedStyle(commentsSection).display === 'none') {
                    commentsSection.style.display = 'block';
                    document.getElementById(`comment-input-${postId}`).focus();
                } else {
                    commentsSection.style.display = 'none';
                }
            }

            // AJAX Like Toggle
            async function toggleLike(postId) {
                try {
                    const response = await fetch(`/posts/${postId}/like`, {
                        method: 'POST',
                        ...fetchConfig
                    });
                    
                    if (response.ok) {
                        const data = await response.json();
                        
                        // Update UI
                        const btn = document.getElementById(`like-btn-${postId}`)
                            || document.querySelector(`.post-card[data-post-id="${postId}"] .like-btn`)
                            || document.querySelector(`.ig-reel[data-post-id="${postId}"] .like-btn`);
                        const icon = document.getElementById(`like-icon-${postId}`);
                        const text = document.getElementById(`like-text-${postId}`);
                        const count = document.getElementById(`likes-count-${postId}`);
                        
                        if (data.status === 'liked') {
                            if (btn) {
                                btn.classList.add('text-danger');
                                btn.classList.remove('text-dark');
                                btn.classList.remove('text-white');
                            }
                            if (icon) icon.classList.replace('fa-regular', 'fa-solid');
                            if (text) text.innerText = 'Liked';
                        } else {
                            if (btn) {
                                btn.classList.remove('text-danger');
                                btn.classList.add('text-dark');
                            }
                            if (icon) icon.classList.replace('fa-solid', 'fa-regular');
                            if (text) text.innerText = 'Like';
                        }
                        
                        if (count) count.innerHTML = `<i class="fa-solid fa-heart text-danger"></i> ${data.likes_count} likes`;
                    }
                } catch (error) {
                    console.error('Error toggling like:', error);
                }
            }

            // AJAX Comment Submit
            async function submitComment(postId) {
                const input = document.getElementById(`comment-input-${postId}`);
                const comment = (input?.value || '').trim();

                if (!comment) return;

                try {
                    const response = await fetch(`/posts/${postId}/comments`, {
                        method: 'POST',
                        ...fetchConfig,
                        body: JSON.stringify({ comment })
                    });
                    
                    if (response.ok) {
                        const data = await response.json();
                        input.value = '';
                        
                        const list = document.getElementById(`comments-list-${postId}`);
                        const newCommentHtml = `
                            <div class="d-flex align-items-start mb-1 small">
                                <span class="text-dark fw-bold me-2">${data.user.name}</span>
                                <span class="text-dark">${data.comment.comment}</span>
                            </div>
                        `;
                        list.insertAdjacentHTML('afterbegin', newCommentHtml);
                    }
                } catch (error) {
                    console.error('Error submitting comment:', error);
                }
            }

            function submitCommentBtn(postId) {
                submitComment(postId);
            }

            async function handleCommentSubmit(event, postId) {
                if (event.key === 'Enter') {
                    event.preventDefault();
                    submitComment(postId);
                }
            }
        </script>
        <x-post-detail-modal />
        @stack('scripts')
    </body>
</html>
