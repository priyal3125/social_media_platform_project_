<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm sticky-top mb-4">
    <div class="container">
        <a class="navbar-brand fw-bold text-primary" href="{{ route('home') }}">
            <i class="fa-solid fa-earth-americas"></i> ConnectHub
        </a>
        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <!-- Left Side Of Navbar (Search) -->
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <form class="d-flex ms-lg-3" action="{{ route('explore') }}" method="GET">
                    <div class="input-group">
                        <span class="input-group-text bg-light border-0"><i class="fa-solid fa-search text-muted"></i></span>
                        <input class="form-control bg-light border-0 rounded-end" type="search" name="q" placeholder="Search ConnectHub" aria-label="Search" style="box-shadow: none;">
                    </div>
                </form>
            </ul>

            <!-- Right Side Of Navbar -->
            <ul class="navbar-nav ms-auto align-items-center">
                <!-- Authentication Links -->
                @guest
                    @if (Route::has('login'))
                        <li class="nav-item">
                            <a class="nav-link fw-bold text-dark" href="{{ route('login') }}">{{ __('Login') }}</a>
                        </li>
                    @endif

                    @if (Route::has('register'))
                        <li class="nav-item">
                            <a class="nav-link btn btn-primary text-white rounded-pill px-3 ms-2" href="{{ route('register') }}">{{ __('Register') }}</a>
                        </li>
                    @endif
                @else
                    <li class="nav-item me-2">
                        <a class="nav-link fs-5 text-dark position-relative" href="{{ route('home') }}" title="Home">
                            <i class="fa-solid fa-house"></i>
                        </a>
                    </li>
                    <li class="nav-item me-2">
                        <a class="nav-link fs-5 text-dark position-relative" href="{{ route('messages.index') }}" title="Messages">
                            <i class="fa-brands fa-facebook-messenger"></i>
                            @php
                                $unreadMessages = auth()->user()->messagesReceived()->where('is_seen', false)->count();
                            @endphp
                            @if($unreadMessages > 0)
                                <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" style="font-size: 0.6rem;">
                                    {{ $unreadMessages }}
                                </span>
                            @endif
                        </a>
                    </li>
                    <li class="nav-item me-2 dropdown">
                        @php
                            $unreadNotificationsCount = auth()->user()->notifications()->where('is_read', false)->count();
                            $latestNotifications = auth()->user()->notifications()->latest()->take(8)->get();
                        @endphp
                        <a class="nav-link fs-5 text-dark position-relative" href="#" id="notificationsDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fa-solid fa-bell"></i>
                            @if($unreadNotificationsCount > 0)
                                <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" style="font-size: 0.6rem;">
                                    {{ $unreadNotificationsCount }}
                                </span>
                            @endif
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end shadow-sm border-0" aria-labelledby="notificationsDropdown" style="width: 300px;">
                            <li class="d-flex align-items-center justify-content-between px-3">
                                <h6 class="dropdown-header fw-bold text-dark px-0 mb-0">Notifications</h6>
                                @if($unreadNotificationsCount > 0)
                                    <form action="{{ route('notifications.readAll') }}" method="POST" class="m-0">
                                        @csrf
                                        <button type="submit" class="btn btn-link p-0 small text-decoration-none">Mark all read</button>
                                    </form>
                                @endif
                            </li>
                            <li><hr class="dropdown-divider"></li>
                            @if($latestNotifications->isEmpty())
                                <li><span class="dropdown-item text-muted small text-center">No notifications</span></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item text-center small" href="{{ route('notifications.index') }}">View all</a></li>
                            @else
                                @foreach($latestNotifications as $notification)
                                    <li>
                                        <a class="dropdown-item {{ $notification->is_read ? '' : 'fw-semibold' }}" href="{{ route('notifications.open', $notification) }}">
                                            <div class="small text-truncate">{{ $notification->message ?: ($notification->title ?: 'Notification') }}</div>
                                            <div class="text-muted" style="font-size: 0.75rem;">{{ $notification->created_at->diffForHumans() }}</div>
                                        </a>
                                    </li>
                                @endforeach
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item text-center small" href="{{ route('notifications.index') }}">View all</a></li>
                            @endif
                        </ul>
                    </li>

                    <li class="nav-item dropdown ms-2">
                        <a class="nav-link p-0 d-flex align-items-center" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <img src="{{ auth()->user()->profile_photo ? asset('storage/'.auth()->user()->profile_photo) : 'https://ui-avatars.com/api/?name='.urlencode(auth()->user()->name) }}" class="rounded-circle border" width="35" height="35" alt="Profile">
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end shadow border-0 mt-2" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="{{ route('profile.show', auth()->user()->username ?? auth()->user()->id) }}"><i class="fa-regular fa-user me-2"></i>Profile</a></li>
                            @if(auth()->user()->is_admin)
                            <li><a class="dropdown-item text-primary" href="{{ route('admin.dashboard') }}"><i class="fa-solid fa-shield-halved me-2"></i>Admin Panel</a></li>
                            @endif
                            <li><a class="dropdown-item" href="{{ route('profile.edit') }}"><i class="fa-solid fa-gear me-2"></i>Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <form method="POST" action="{{ route('logout') }}">
                                    @csrf
                                    <a class="dropdown-item text-danger" href="{{ route('logout') }}" onclick="event.preventDefault(); this.closest('form').submit();">
                                        <i class="fa-solid fa-arrow-right-from-bracket me-2"></i>{{ __('Log Out') }}
                                    </a>
                                </form>
                            </li>
                        </ul>
                    </li>
                @endguest
            </ul>
        </div>
    </div>
</nav>
