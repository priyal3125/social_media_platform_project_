<aside class="ig-sidebar">
    <div class="mb-5 text-center text-lg-start">
        <a class="ig-nav-brand mb-0" href="{{ route('home') }}">
            <i class="fa-solid fa-earth-americas"></i>
            <span>{{ config('app.name', 'ConnectHub') }}</span>
        </a>
    </div>

    @php
        $unreadNotificationsCount = auth()->user()->notifications()->where('is_read', false)->count();
    @endphp

    <div class="d-flex flex-column gap-2 flex-grow-1">
        <a class="ig-nav-item {{ request()->routeIs('home') ? 'active' : '' }}" href="{{ route('home') }}">
            <i class="fa-solid fa-house-chimney"></i>
            <span>Feed</span>
        </a>

        <a class="ig-nav-item {{ request()->routeIs('explore') ? 'active' : '' }}" href="{{ route('explore') }}">
            <i class="fa-solid fa-compass"></i>
            <span>Discovery</span>
        </a>

        <a class="ig-nav-item {{ request()->routeIs('reels.*') ? 'active' : '' }}" href="{{ route('reels.index') }}">
            <i class="fa-solid fa-clapperboard"></i>
            <span>Moments</span>
        </a>

        <a class="ig-nav-item {{ request()->routeIs('messages.*') ? 'active' : '' }}" href="{{ route('messages.index') }}">
            <i class="fa-solid fa-paper-plane"></i>
            <span>Messages</span>
        </a>

        <a class="ig-nav-item {{ request()->routeIs('notifications.*') || request()->routeIs('notification') ? 'active' : '' }}" href="{{ route('notifications.index') }}">
            <i class="fa-solid fa-bell"></i>
            <span>Alerts</span>
            @if($unreadNotificationsCount > 0)
                <span class="ms-auto badge rounded-pill bg-danger shadow-sm" style="font-size: 0.6rem;">{{ $unreadNotificationsCount }}</span>
            @endif
        </a>

        <a class="ig-nav-item {{ request()->routeIs('profile.show') ? 'active' : '' }}" href="{{ route('profile.show', auth()->user()->username ?? auth()->user()->id) }}">
            <i class="fa-solid fa-circle-user"></i>
            <span>Me</span>
        </a>

        <a class="ig-nav-item {{ request()->routeIs('profile.edit') ? 'active' : '' }}" href="{{ route('profile.edit') }}">
            <i class="fa-solid fa-sliders"></i>
            <span>Setting</span>
        </a>

    </div>

    <div class="mt-auto">
        <div class="ig-card p-3 border-0 bg-light-subtle shadow-sm mb-3">
            <div class="d-flex align-items-center gap-2">
                <div class="position-relative">
                    <img src="{{ auth()->user()->profile_photo ? asset('storage/'.auth()->user()->profile_photo) : 'https://ui-avatars.com/api/?name='.urlencode(auth()->user()->name) }}" width="40" height="40" class="rounded-circle shadow-sm border border-2 border-white" style="object-fit: cover;" alt="Profile">
                    <span class="position-absolute bottom-0 end-0 bg-success border border-2 border-white rounded-circle" style="width: 12px; height: 12px;"></span>
                </div>
                <div class="min-w-0 d-none d-lg-block">
                    <div class="fw-bold small text-truncate">{{ auth()->user()->name }}</div>
                    <div class="ig-muted text-truncate" style="font-size: 0.75rem;">{{ '@'.auth()->user()->username }}</div>
                </div>
            </div>
        </div>

        <form method="POST" action="{{ route('logout') }}">
            @csrf
            <button type="submit" class="btn btn-light w-100 ig-btn small py-2 d-flex align-items-center justify-content-center gap-2 opacity-75 hover-opacity-100">
                <i class="fa-solid fa-power-off fs-6"></i>
                <span class="d-none d-lg-inline">End Session</span>
            </button>
        </form>
    </div>
</aside>
