<x-guest-layout>
    <div class="auth-badge">Welcome Back</div>
    <h2 class="fw-bold mb-2">Sign in</h2>
    <p class="text-muted mb-4">Enter your credentials to access your feed.</p>
    
    @if(session('status'))
        <div class="alert alert-success border-0 shadow-sm small mb-4">
            {{ session('status') }}
        </div>
    @endif

    <form method="POST" action="{{ route('login') }}">
        @csrf

        <div class="mb-3">
            <label for="email" class="form-label small fw-semibold text-secondary">{{ __('Email Address') }}</label>
            <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autofocus placeholder="name@example.com">
            @error('email')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="mb-3">
            <div class="d-flex justify-content-between">
                <label for="password" class="form-label small fw-semibold text-secondary">{{ __('Password') }}</label>
                @if (Route::has('password.request'))
                    <a class="small text-decoration-none fw-semibold" href="{{ route('password.request') }}">
                        Forgot?
                    </a>
                @endif
            </div>
            <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required placeholder="••••••••">
            @error('password')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="mb-4 form-check">
            <input type="checkbox" class="form-check-input" id="remember_me" name="remember">
            <label class="form-check-label small text-muted" for="remember_me">{{ __('Keep me signed in') }}</label>
        </div>

        <button type="submit" class="btn btn-primary w-100 ig-btn py-3 mb-4">
            {{ __('Sign In') }}
        </button>
        
        <div class="text-center">
            <span class="text-muted small">New to ConnectHub?</span> 
            <a href="{{ route('register') }}" class="text-decoration-none fw-bold small ms-1 text-primary">Create Account</a>
        </div>
    </form>
</x-guest-layout>
