<x-guest-layout>
    <div class="auth-badge">Get Started</div>
    <h2 class="fw-bold mb-2">Create Account</h2>
    <p class="text-muted mb-4">Join our community of creators and explorers.</p>

    <form method="POST" action="{{ route('register') }}">
        @csrf

        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="name" class="form-label small fw-semibold text-secondary">{{ __('Full Name') }}</label>
                <input id="name" type="text" class="form-control @error('name') is-invalid @enderror" name="name" value="{{ old('name') }}" required autofocus placeholder="John Doe">
                @error('name')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>
            <div class="col-md-6 mb-3">
                <label for="username" class="form-label small fw-semibold text-secondary">{{ __('Username') }}</label>
                <div class="input-group">
                    <span class="input-group-text bg-transparent border-end-0 text-muted">@</span>
                    <input id="username" type="text" class="form-control border-start-0 ps-0 @error('username') is-invalid @enderror" name="username" value="{{ old('username') }}" required placeholder="johndoe">
                </div>
                @error('username')
                    <div class="invalid-feedback d-block">{{ $message }}</div>
                @enderror
            </div>
        </div>

        <div class="mb-3">
            <label for="email" class="form-label small fw-semibold text-secondary">{{ __('Email Address') }}</label>
            <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required placeholder="name@example.com">
            @error('email')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="mb-3">
            <label for="password" class="form-label small fw-semibold text-secondary">{{ __('Password') }}</label>
            <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required placeholder="Choose a strong password">
            @error('password')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="mb-4">
            <label for="password_confirmation" class="form-label small fw-semibold text-secondary">{{ __('Confirm Password') }}</label>
            <input id="password_confirmation" type="password" class="form-control" name="password_confirmation" required placeholder="Repeat password">
        </div>

        <button type="submit" class="btn btn-primary w-100 ig-btn py-3 mb-4">
            {{ __('Create Account') }}
        </button>

        <div class="text-center">
            <span class="text-muted small">Already have an account?</span> 
            <a href="{{ route('login') }}" class="text-decoration-none fw-bold small ms-1 text-primary">Sign in</a>
        </div>
    </form>
</x-guest-layout>
