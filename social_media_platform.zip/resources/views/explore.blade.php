<x-app-layout>
    @php
        /**
         * Returns a guaranteed-unique image URL per post.
         * - If the post has a real uploaded image  → use it.
         * - Otherwise use Picsum with the post's own ID as seed
         *   (same ID always → same photo, different IDs → different photos).
         */
        $categoryKeyword = [
            'Travel'  => 'travel,landscape',
            'Food'    => 'food,cooking',
            'Nature'  => 'nature,forest',
            'Art'     => 'art,painting',
            'Fashion' => 'fashion,style',
            'Tech'    => 'technology,computer',
            'People'  => 'people,portrait',
        ];

        /**
         * Returns a category-matched image URL per post.
         * - If the post has a real uploaded image  → use it.
         * - Otherwise use loremflickr.com with the post category keyword
         *   so Food → food photos, Nature → nature photos, etc.
         */
        $getPostImageUrl = function ($post) use ($categoryKeyword) {
            if ($post->image) {
                return asset('storage/' . $post->image);
            }
            $keyword = $categoryKeyword[$post->category] ?? 'photography';
            return 'https://loremflickr.com/800/600/' . urlencode($keyword) . '?lock=' . $post->id;
        };

        /**
         * Vary card height for the masonry aesthetic.
         * Bins: short / medium / tall  based on post ID mod 3.
         */
        $cardHeight = function ($post) {
            $mod = $post->id % 3;
            return match($mod) {
                0 => '220px',
                1 => '300px',
                default => '260px',
            };
        };
    @endphp

    {{-- =====================  PAGE STYLES  ======================== --}}
    <style>
        /* ── Typography ── */
        @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap');

        /* ── Hero header ── */
        .explore-hero {
            text-align: center;
            padding: 2.5rem 1rem 1.5rem;
        }
        .explore-hero h1 {
            font-family: 'Outfit', sans-serif;
            font-size: clamp(2rem, 5vw, 3.2rem);
            font-weight: 800;
            background: linear-gradient(135deg, #4A90E2, #FFB6C1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: .5rem;
        }
        .explore-hero p {
            color: #888;
            font-size: 1.05rem;
            max-width: 520px;
            margin: 0 auto 1.8rem;
        }

        /* ── Search bar ── */
        .explore-search-wrap {
            max-width: 600px;
            margin: 0 auto 2rem;
            background: #fff;
            border-radius: 999px;
            box-shadow: 0 4px 28px rgba(0,0,0,.10);
            display: flex;
            align-items: center;
            padding: .35rem .35rem .35rem 1.2rem;
            gap: .5rem;
            border: 1.5px solid #f0f0f0;
            transition: box-shadow .25s;
        }
        .explore-search-wrap:focus-within {
            box-shadow: 0 6px 36px rgba(131,58,180,.18);
            border-color: #c56cd6;
        }
        .explore-search-wrap input {
            border: none;
            outline: none;
            flex: 1;
            font-size: 1rem;
            font-family: 'Outfit', sans-serif;
            background: transparent;
            color: #222;
        }
        .explore-search-wrap input::placeholder { color: #aaa; }
        .explore-search-btn {
            background: linear-gradient(135deg, #4A90E2, #FFB6C1);
            color: #fff;
            border: none;
            border-radius: 999px;
            padding: .55rem 1.4rem;
            font-family: 'Outfit', sans-serif;
            font-weight: 600;
            cursor: pointer;
            white-space: nowrap;
            transition: opacity .2s, transform .15s;
        }
        .explore-search-btn:hover { opacity: .88; transform: scale(1.03); }

        /* ── Filter chips ── */
        .explore-chips {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: .55rem;
            margin-bottom: 2rem;
        }
        .chip {
            font-family: 'Outfit', sans-serif;
            font-size: .82rem;
            font-weight: 600;
            padding: .38rem 1rem;
            border-radius: 999px;
            border: 1.5px solid #e8e8e8;
            background: #fff;
            color: #555;
            cursor: pointer;
            transition: all .2s;
            text-decoration: none;
        }
        .chip:hover, .chip.active {
            background: linear-gradient(135deg, #4A90E2, #FFB6C1);
            color: #fff;
            border-color: transparent;
        }

        /* ══════════════════════════════════════════
           MASONRY GRID  (CSS columns — zero JS)
        ══════════════════════════════════════════ */
        .masonry-grid {
            column-count: 4;
            column-gap: 14px;
            padding: 0 4px;
        }
        @media (max-width: 1200px) { .masonry-grid { column-count: 3; } }
        @media (max-width: 768px)  { .masonry-grid { column-count: 2; column-gap: 10px; } }
        @media (max-width: 480px)  { .masonry-grid { column-count: 2; column-gap: 8px; } }

        /* ── Individual card ── */
        .masonry-card {
            break-inside: avoid;
            display: inline-block; /* required for column layout */
            width: 100%;
            margin-bottom: 14px;
            border-radius: 16px;
            overflow: hidden;
            position: relative;
            cursor: pointer;
            background: #f0f0f0;
            box-shadow: 0 2px 14px rgba(0,0,0,.07);
            transition: transform .28s cubic-bezier(.34,1.56,.64,1),
                        box-shadow .28s ease;
        }
        @media (max-width: 768px) { .masonry-card { margin-bottom: 10px; border-radius: 12px; } }
        .masonry-card:hover {
            transform: translateY(-6px) scale(1.012);
            box-shadow: 0 16px 44px rgba(0,0,0,.18);
            z-index: 2;
        }

        /* ── Card image ── */
        .masonry-card img,
        .masonry-card video {
            width: 100%;
            display: block;
            object-fit: cover;
            transition: transform .35s ease;
        }
        .masonry-card:hover img,
        .masonry-card:hover video {
            transform: scale(1.05);
        }

        /* ── Gradient overlay ── */
        .masonry-overlay {
            position: absolute;
            bottom: 0; left: 0; right: 0;
            padding: 2.5rem 1rem 1rem;
            background: linear-gradient(to top, rgba(0,0,0,.72) 0%, transparent 100%);
            opacity: 0;
            transition: opacity .28s ease;
            display: flex;
            flex-direction: column;
            justify-content: flex-end;
        }
        .masonry-card:hover .masonry-overlay { opacity: 1; }

        .masonry-overlay .card-user {
            font-family: 'Outfit', sans-serif;
            font-size: .8rem;
            font-weight: 600;
            color: rgba(255,255,255,.85);
            text-transform: uppercase;
            letter-spacing: .06em;
            margin-bottom: .25rem;
        }
        .masonry-overlay .card-title {
            font-family: 'Outfit', sans-serif;
            font-size: .95rem;
            font-weight: 700;
            color: #fff;
            line-height: 1.3;
            margin-bottom: .4rem;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }
        .masonry-overlay .card-meta {
            display: flex;
            align-items: center;
            gap: .5rem;
            font-size: .75rem;
            color: rgba(255,255,255,.7);
        }

        /* ── Video badge ── */
        .video-badge {
            position: absolute;
            top: 10px; right: 10px;
            background: rgba(0,0,0,.55);
            color: #fff;
            border-radius: 8px;
            padding: .25rem .55rem;
            font-size: .75rem;
            font-weight: 600;
            backdrop-filter: blur(4px);
            font-family: 'Outfit', sans-serif;
        }



        /* ── Shimmer skeleton ── */
        .shimmer-card {
            break-inside: avoid;
            display: inline-block;
            width: 100%;
            margin-bottom: 14px;
            border-radius: 16px;
            background: linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 50%, #f0f0f0 75%);
            background-size: 200% 100%;
            animation: shimmer 1.5s infinite;
        }
        @keyframes shimmer {
            0%   { background-position: 200% 0; }
            100% { background-position: -200% 0; }
        }

        /* ── Empty state ── */
        .empty-state {
            text-align: center;
            padding: 5rem 1rem;
        }
        .empty-state i {
            font-size: 4rem;
            color: #ddd;
            margin-bottom: 1.2rem;
            display: block;
        }
        .empty-state h4 {
            font-family: 'Outfit', sans-serif;
            font-weight: 700;
            color: #333;
            margin-bottom: .5rem;
        }
        .empty-state p { color: #aaa; font-size: .95rem; }
        .empty-state a {
            margin-top: 1.2rem;
            display: inline-block;
            background: linear-gradient(135deg, #833ab4, #fd1d1d);
            color: #fff;
            padding: .6rem 1.6rem;
            border-radius: 999px;
            font-family: 'Outfit', sans-serif;
            font-weight: 600;
            text-decoration: none;
        }

        /* ── Pagination ── */
        .explore-pagination { margin: 2.5rem 0 4rem; display: flex; justify-content: center; }
        .explore-pagination .page-link {
            font-family: 'Outfit', sans-serif;
            border-radius: 10px !important;
            margin: 0 3px;
            border: 1.5px solid #eee;
            color: #555;
            transition: all .2s;
        }
        .explore-pagination .page-item.active .page-link,
        .explore-pagination .page-link:hover {
            background: linear-gradient(135deg, #4A90E2, #FFB6C1);
            border-color: transparent;
            color: #fff;
        }

        /* ── Results count badge ── */
        .results-badge {
            font-family: 'Outfit', sans-serif;
            font-size: .82rem;
            font-weight: 600;
            color: #888;
            text-align: center;
            margin-bottom: 1.2rem;
        }
        .results-badge span {
            background: #f4f4f4;
            border-radius: 999px;
            padding: .3rem .9rem;
        }
    </style>

    {{-- =====================  HERO  ======================== --}}
    <div class="explore-hero">
        <h1>✦ Discover</h1>
        <p>Explore hand-picked moments from our global community — every photo unique.</p>

        {{-- Search Bar --}}
        <form action="{{ route('explore') }}" method="GET" id="explore-search-form">
            <div class="explore-search-wrap">
                <i class="fa-solid fa-magnifying-glass" style="color:#bbb;"></i>
                <input
                    type="text"
                    name="q"
                    id="explore-q"
                    value="{{ request('q') }}"
                    placeholder="Search creators, moments, or hashtags…"
                    autocomplete="off"
                >
                <button type="submit" class="explore-search-btn">
                    <i class="fa-solid fa-arrow-right me-1"></i> Search
                </button>
            </div>
        </form>

        {{-- Quick-filter chips --}}
        <div class="explore-chips">
    <button type="button" data-category="All" class="chip active">🔥 All</button>
    <button type="button" data-category="Travel" class="chip">Travel</button>
    <button type="button" data-category="Food" class="chip">Food</button>
    <button type="button" data-category="Nature" class="chip">Nature</button>
    <button type="button" data-category="Art" class="chip">Art</button>
    <button type="button" data-category="Fashion" class="chip">Fashion</button>
    <button type="button" data-category="Tech" class="chip">Tech</button>
    <button type="button" data-category="People" class="chip">People</button>
</div>
    </div>

    {{-- =====================  GRID  ======================== --}}
    @if($posts->isEmpty())
        <div class="empty-state">
            <i class="fa-solid fa-compass"></i>
            <h4>Nothing to discover yet</h4>
            <p>No posts matched your search. Try a different keyword or browse all.</p>
            <a href="{{ route('explore') }}">← Clear filters</a>
        </div>
    @else
        <div class="results-badge">
            <span>{{ $posts->total() }} unique {{ Str::plural('post', $posts->total()) }} found</span>
        </div>

        {{-- Masonry grid --}}
        <div class="masonry-grid" id="masonry-grid">
            @foreach($posts as $post)
                @php
                    $imgUrl    = $getPostImageUrl($post);
                    $videoUrl  = $post->video ? asset('storage/' . $post->video) : '';
                    $avatar    = $post->user->profile_photo
                                    ? asset('storage/' . $post->user->profile_photo)
                                    : 'https://ui-avatars.com/api/?name=' . urlencode($post->user->name) . '&background=random&size=64';
                    $username  = $post->user->username ?? $post->user->name;
                    $title     = $post->title ?: $post->content ?: $username;
                    $views     = number_format($post->views_count ?? 0);
                    $likes     = $post->likes->count();
                    $imgH      = $cardHeight($post);
                @endphp

                <div class="masonry-card"
                     data-trigger-post-modal
                     data-post-id="{{ $post->id }}"
                     data-post-image-grid="{{ $imgUrl }}"
                     data-post-image-modal="{{ $imgUrl }}"
                     data-post-video="{{ $videoUrl }}"
                     data-post-profile="{{ $avatar }}"
                     data-post-user="{{ $username }}"
                     data-post-filename="{{ $post->image ? basename($post->image) : ('post-' . $post->id . '.jpg') }}"
                     data-post-views="{{ $post->views_count ?? 0 }}"
                     data-post-caption="{{ e($post->content ?? '') }}"
                     data-post-title="{{ e($post->title ?? '') }}"
                     role="button"
                     tabindex="0"
                     aria-label="View post by {{ $username }}">



                    {{-- Video badge --}}
                    @if($videoUrl)
                        <span class="video-badge"><i class="fa-solid fa-clapperboard me-1"></i>Reel</span>
                    @endif

                    {{-- Media --}}
                    @if($videoUrl)
                        <video src="{{ $videoUrl }}"
                               style="height: {{ $imgH }};"
                               muted playsinline preload="none"
                               loading="lazy"></video>
                    @else
                        <img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1 1'%3E%3C/svg%3E"
                             data-src="{{ $imgUrl }}"
                             class="lazyload"
                             style="height: {{ $imgH }}; background: #ececec;"
                             alt="{{ e($title) }}"
                             onerror="this.onerror=null;this.src='https://picsum.photos/seed/fallback-{{ $post->id }}/800/600';">
                    @endif

                    {{-- Gradient overlay --}}
                    <div class="masonry-overlay">
                        <div class="card-user">@{{ $username }}</div>
                        <div class="card-title">{{ Str::limit($title, 60) }}</div>
                        <div class="card-meta">
                            <span><i class="fa-solid fa-eye me-1"></i>{{ $views }}</span>
                            <span>·</span>
                            <span><i class="fa-solid fa-heart me-1" style="color:#ff6b8a;"></i>{{ $likes }}</span>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>

        {{-- Pagination --}}
        <div class="explore-pagination">
            {{ $posts->links('pagination::bootstrap-5') }}
        </div>
    @endif

    {{-- =====================  SCRIPTS  ======================== --}}
    @push('scripts')
    <script>
    /**
     * AJAX Category & Search Filtering
     */
    (function () {
        let grid            = document.getElementById('masonry-grid');
        const searchInput   = document.getElementById('explore-q');
        const searchForm    = document.getElementById('explore-search-form');
        const categoryButtons = document.querySelectorAll('.explore-chips button.chip');
        const paginationWrap  = document.querySelector('.explore-pagination');
        const resultsBadge    = document.querySelector('.results-badge span');

        let currentCategory = 'All';

        /** Ensure the masonry grid container exists even if page started empty */
        const ensureGrid = () => {
            grid = document.getElementById('masonry-grid');
            if (!grid) {
                // Create the grid if the page initially had no posts
                const wrap = document.createElement('div');
                wrap.className = 'masonry-grid';
                wrap.id = 'masonry-grid';
                const paginationEl = document.querySelector('.explore-pagination');
                if (paginationEl) {
                    paginationEl.insertAdjacentElement('beforebegin', wrap);
                } else {
                    document.querySelector('.explore-hero').insertAdjacentElement('afterend', wrap);
                }
                grid = wrap;
            }
        };

        const fetchFilteredPosts = async () => {
            ensureGrid();
            const searchQuery = searchInput ? searchInput.value : '';
            const url = new URL(window.location.href);
            url.searchParams.set('category', currentCategory);
            url.searchParams.set('q', searchQuery);
            url.searchParams.set('page', 1);

            // Show loading state
            grid.style.opacity = '0.5';
            grid.style.pointerEvents = 'none';

            try {
                const response = await fetch(url, {
                    headers: { 'X-Requested-With': 'XMLHttpRequest' }
                });
                const data = await response.json();

                // Update Grid
                if (!data.html || data.html.trim() === '') {
                    grid.innerHTML = `
                        <div class="empty-state" style="column-span: all; width: 100%;">
                            <i class="fa-solid fa-compass"></i>
                            <h4>No posts found</h4>
                            <p>Try a different category or search term.</p>
                        </div>`;
                } else {
                    grid.innerHTML = data.html;
                }

                // Update results count badge safely
                if (resultsBadge) {
                    resultsBadge.innerText = `${data.total} unique ${data.total === 1 ? 'post' : 'posts'} found`;
                }

                // Hide pagination on AJAX
                if (paginationWrap) paginationWrap.style.display = 'none';

                // Re-attach keyboard listeners for modal
                attachCardListeners();

            } catch (error) {
                console.error('Error fetching posts:', error);
                grid.innerHTML = `<div class="empty-state"><i class="fa-solid fa-triangle-exclamation"></i><h4>Something went wrong</h4><p>Please refresh and try again.</p></div>`;
            } finally {
                grid.style.opacity = '1';
                grid.style.pointerEvents = 'auto';
            }
        };

        const attachCardListeners = () => {
            document.querySelectorAll('.masonry-card[data-trigger-post-modal]').forEach(card => {
                card.addEventListener('keydown', e => {
                    if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        card.click();
                    }
                });
            });
        };

        // Category chip clicks
        categoryButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                categoryButtons.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                currentCategory = btn.dataset.category;
                fetchFilteredPosts();
            });
        });

        // Search form submit
        if (searchForm) {
            searchForm.addEventListener('submit', (e) => {
                e.preventDefault();
                fetchFilteredPosts();
            });
        }

        // Escape clears search
        if (searchInput) {
            searchInput.addEventListener('keydown', e => {
                if (e.key === 'Escape') {
                    searchInput.value = '';
                    fetchFilteredPosts();
                }
            });
        }

        /** Lazy-load images on the INITIAL Blade render (data-src → src via IntersectionObserver) */
        const initLazyLoad = () => {
            const lazyImgs = document.querySelectorAll('img.lazyload[data-src]');
            if (!lazyImgs.length) return;

            if (!('IntersectionObserver' in window)) {
                lazyImgs.forEach(img => { img.src = img.dataset.src; img.classList.remove('lazyload'); });
                return;
            }
            const io = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (!entry.isIntersecting) return;
                    const img = entry.target;
                    img.src = img.dataset.src;
                    img.onload = () => img.classList.add('loaded');
                    img.classList.remove('lazyload');
                    observer.unobserve(img);
                });
            }, { rootMargin: '200px 0px' });
            lazyImgs.forEach(img => io.observe(img));
        };

        // Initialize on page load
        initLazyLoad();
        attachCardListeners();
    })();
    </script>

    <style>
    /* Lazy-loaded image fade-in */
    img.lazyload {
        opacity: 0;
        transition: opacity .45s ease;
    }
    img.lazyload.loaded,
    img:not(.lazyload) {
        opacity: 1;
    }
    /* Smooth fade once src is swapped */
    img[data-src]:not(.lazyload) {
        animation: fadeImg .45s ease forwards;
    }
    @keyframes fadeImg {
        from { opacity: 0; }
        to   { opacity: 1; }
    }
    </style>
    @endpush

</x-app-layout>
