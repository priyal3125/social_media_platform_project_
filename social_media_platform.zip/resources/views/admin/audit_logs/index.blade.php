@extends('layouts.admin')

@section('header', 'Audit Logs')

@section('content')
<div class="glass rounded-3xl overflow-hidden">
    <div class="p-6 border-b border-white/5 flex justify-between items-center">
        <h2 class="text-lg font-bold">System Activity</h2>
        <div class="flex space-x-2">
            <button onclick="exportToCSV()" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 rounded-xl text-sm font-bold transition-colors">Export CSV</button>
        </div>
    </div>
    
    <script>
        function exportToCSV() {
            let csv = [];
            const rows = document.querySelectorAll("table tr");
            
            for (const row of rows) {
                const cols = row.querySelectorAll("td, th");
                const rowData = [];
                for (const col of cols) rowData.push('"' + col.innerText.replace(/"/g, '""') + '"');
                csv.push(rowData.join(","));
            }

            const csvFile = new Blob([csv.join("\n")], { type: "text/csv" });
            const downloadLink = document.createElement("a");
            downloadLink.download = "audit_logs.csv";
            downloadLink.href = window.URL.createObjectURL(csvFile);
            downloadLink.style.display = "none";
            document.body.appendChild(downloadLink);
            downloadLink.click();
        }
    </script>
    <div class="overflow-x-auto">
        <table class="w-full text-left">
            <thead class="bg-white/5">
                <tr>
                    <th class="px-6 py-4 text-xs font-bold uppercase text-slate-400">Admin</th>
                    <th class="px-6 py-4 text-xs font-bold uppercase text-slate-400">Action</th>
                    <th class="px-6 py-4 text-xs font-bold uppercase text-slate-400">Target</th>
                    <th class="px-6 py-4 text-xs font-bold uppercase text-slate-400">IP Address</th>
                    <th class="px-6 py-4 text-xs font-bold uppercase text-slate-400">Date</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-white/5">
                @foreach($logs as $log)
                <tr class="hover:bg-white/5 transition-colors">
                    <td class="px-6 py-4">
                        <div class="flex items-center space-x-3">
                            <img src="https://ui-avatars.com/api/?name={{ urlencode($log->admin->name) }}" class="h-8 w-8 rounded-lg" alt="">
                            <span class="text-sm font-medium">{{ $log->admin->name }}</span>
                        </div>
                    </td>
                    <td class="px-6 py-4 text-sm font-semibold">
                        {{ strtoupper(str_replace('_', ' ', $log->action)) }}
                    </td>
                    <td class="px-6 py-4 text-sm text-slate-400">
                        {{ $log->target_type ? class_basename($log->target_type) . ' #' . $log->target_id : 'N/A' }}
                    </td>
                    <td class="px-6 py-4 text-sm font-mono text-slate-500">
                        {{ $log->ip_address }}
                    </td>
                    <td class="px-6 py-4 text-sm text-slate-400">
                        {{ $log->created_at->format('M d, Y H:i') }}
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
    <div class="p-6 border-t border-white/5">
        {{ $logs->links() }}
    </div>
</div>
@endsection
