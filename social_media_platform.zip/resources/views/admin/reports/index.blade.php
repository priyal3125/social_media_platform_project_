@extends('layouts.admin')

@section('header', 'Reports Overview')

@section('content')
<div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
    <div class="glass p-6 rounded-3xl">
        <p class="text-slate-400 text-xs font-bold uppercase mb-2">Total Reports</p>
        <h4 class="text-3xl font-bold text-white">{{ number_format($stats['total']) }}</h4>
    </div>
    <div class="glass p-6 rounded-3xl">
        <p class="text-slate-400 text-xs font-bold uppercase mb-2 text-rose-400">Needs Action</p>
        <h4 class="text-3xl font-bold text-rose-500">{{ number_format($stats['pending']) }}</h4>
    </div>
    <div class="glass p-6 rounded-3xl">
        <p class="text-slate-400 text-xs font-bold uppercase mb-2 text-emerald-400">Resolved</p>
        <h4 class="text-3xl font-bold text-emerald-500">{{ number_format($stats['resolved']) }}</h4>
    </div>
</div>

<div class="glass rounded-3xl overflow-hidden">
    <div class="p-6 border-b border-white/5">
        <h2 class="text-lg font-bold">Comprehensive Reports Index</h2>
    </div>
    <table class="w-full text-left">
        <thead class="bg-white/5">
            <tr>
                <th class="px-6 py-4 text-xs font-bold uppercase text-slate-400">Reporter</th>
                <th class="px-6 py-4 text-xs font-bold uppercase text-slate-400">Content Type</th>
                <th class="px-6 py-4 text-xs font-bold uppercase text-slate-400">Status</th>
                <th class="px-6 py-4 text-xs font-bold uppercase text-slate-400">Date</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-white/5">
            @foreach($reports as $report)
            <tr class="hover:bg-white/5 transition-colors">
                <td class="px-6 py-4 text-sm font-medium">{{ $report->reporter->name }}</td>
                <td class="px-6 py-4 text-sm font-mono text-indigo-400">{{ class_basename($report->reportable_type) }}</td>
                <td class="px-6 py-4">
                    <span class="px-2 py-1 rounded-lg text-xs font-extrabold uppercase {{ $report->status === 'pending' ? 'bg-rose-500/10 text-rose-500' : 'bg-slate-500/10 text-slate-400' }}">
                        {{ $report->status }}
                    </span>
                </td>
                <td class="px-6 py-4 text-sm text-slate-500">{{ $report->created_at->diffForHumans() }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>
    <div class="p-6 border-t border-white/5">
        {{ $reports->links() }}
    </div>
</div>
@endsection
