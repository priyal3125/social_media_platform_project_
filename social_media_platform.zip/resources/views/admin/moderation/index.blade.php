@extends('layouts.admin')

@section('header', 'Moderation Queue')

@section('content')
<div class="glass rounded-3xl overflow-hidden">
    <table class="w-full text-left">
        <thead class="bg-white/5">
            <tr>
                <th class="px-6 py-4 text-xs font-bold uppercase text-slate-400">Reporter</th>
                <th class="px-6 py-4 text-xs font-bold uppercase text-slate-400">Type</th>
                <th class="px-6 py-4 text-xs font-bold uppercase text-slate-400">Reason</th>
                <th class="px-6 py-4 text-xs font-bold uppercase text-slate-400">Status</th>
                <th class="px-6 py-4 text-xs font-bold uppercase text-slate-400 text-right">Actions</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-white/5">
            @foreach($reports as $report)
            <tr class="hover:bg-white/5 transition-colors group">
                <td class="px-6 py-4">
                    <div class="flex items-center space-x-3">
                        <img src="https://ui-avatars.com/api/?name={{ urlencode($report->reporter->name) }}" class="h-8 w-8 rounded-lg" alt="">
                        <span class="text-sm font-medium">{{ $report->reporter->name }}</span>
                    </div>
                </td>
                <td class="px-6 py-4 text-sm">
                    <span class="px-2 py-1 rounded-lg bg-indigo-500/10 text-indigo-400 font-semibold text-xs">
                        {{ class_basename($report->reportable_type) }}
                    </span>
                </td>
                <td class="px-6 py-4 text-sm text-slate-400 italic">
                    {{ Str::limit($report->reason, 50) }}
                </td>
                <td class="px-6 py-4">
                    <span class="px-2 py-1 rounded-lg text-xs font-bold uppercase 
                        @if($report->status === 'pending') bg-rose-500/10 text-rose-500 
                        @elseif($report->status === 'under_review') bg-amber-500/10 text-amber-500
                        @elseif($report->status === 'approved') bg-emerald-500/10 text-emerald-500
                        @else bg-slate-500/10 text-slate-400 @endif">
                        {{ str_replace('_', ' ', $report->status) }}
                    </span>
                </td>
                <td class="px-6 py-4 text-right">
                    <div x-data="{ open: false }" class="relative">
                        <button @click="open = !open" class="p-2 text-slate-400 hover:text-white transition-colors">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z"></path></svg>
                        </button>
                        
                        <div x-show="open" @click.away="open = false" 
                             class="absolute right-0 mt-2 w-48 glass rounded-2xl shadow-xl z-20 overflow-hidden border border-white/10"
                             x-transition:enter="transition ease-out duration-100"
                             x-transition:enter-start="transform opacity-0 scale-95"
                             x-transition:enter-end="transform opacity-100 scale-100">
                            <form action="{{ route('admin.moderation.update', $report) }}" method="POST">
                                @csrf
                                @method('PATCH')
                                <input type="hidden" name="status" id="status_{{ $report->id }}">
                                <button type="submit" onclick="document.getElementById('status_{{ $report->id }}').value='under_review'" class="w-full text-left px-4 py-2 text-xs font-semibold hover:bg-white/5 transition-colors">Review</button>
                                <button type="submit" onclick="document.getElementById('status_{{ $report->id }}').value='approved'" class="w-full text-left px-4 py-2 text-xs font-semibold hover:bg-emerald-500/10 text-emerald-400 transition-colors border-t border-white/5">Approve</button>
                                <button type="submit" onclick="document.getElementById('status_{{ $report->id }}').value='removed'" class="w-full text-left px-4 py-2 text-xs font-semibold hover:bg-rose-500/10 text-rose-500 transition-colors border-t border-white/5">Remove Content</button>
                            </form>
                        </div>
                    </div>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
    
    <div class="p-6 border-t border-white/5">
        {{ $reports->links() }}
    </div>
</div>
@endsection
