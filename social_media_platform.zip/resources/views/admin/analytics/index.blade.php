@extends('layouts.admin')

@section('header', 'Platform Analytics')

@section('content')
<div class="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
    <div class="glass p-8 rounded-3xl col-span-2">
        <h3 class="text-xl font-bold mb-6">User Growth (Last 7 Days)</h3>
        <div class="h-64 flex items-end justify-between space-x-2">
            @foreach($user_growth as $day)
                <div class="flex-1 flex flex-col items-center">
                    <div class="w-full bg-indigo-500/20 rounded-t-xl relative group" style="height: {{ ($day->count / max($user_growth->pluck('count')->toArray() ?: [1])) * 100 }}%">
                        <div class="absolute -top-10 left-1/2 -translate-x-1/2 bg-indigo-600 text-[10px] font-bold px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity">
                            {{ $day->count }} users
                        </div>
                    </div>
                    <span class="text-[10px] text-slate-500 mt-2 rotate-45 transform origin-top-left whitespace-nowrap">{{ $day->date }}</span>
                </div>
            @endforeach
        </div>
    </div>

    <div class="glass p-8 rounded-3xl">
        <h3 class="text-xl font-bold mb-6">Activity Ratios</h3>
        <div class="space-y-6">
            <div>
                <div class="flex justify-between text-sm mb-2">
                    <span class="text-slate-400 font-medium whitespace-nowrap overflow-hidden text-ellipsis">Likes per Post</span>
                    <span class="font-bold">{{ $post_stats['total'] > 0 ? round($post_stats['likes'] / $post_stats['total'], 1) : 0 }}</span>
                </div>
                <div class="w-full h-2 bg-white/5 rounded-full overflow-hidden">
                    <div class="h-full bg-emerald-500" style="width: {{ min(($post_stats['likes'] / max($post_stats['total'] ?: 1, 1)) * 10, 100) }}%"></div>
                </div>
            </div>
            <div>
                <div class="flex justify-between text-sm mb-2">
                    <span class="text-slate-400 font-medium whitespace-nowrap overflow-hidden text-ellipsis">Comments per Post</span>
                    <span class="font-bold">{{ $post_stats['total'] > 0 ? round($post_stats['comments'] / $post_stats['total'], 1) : 0 }}</span>
                </div>
                <div class="w-full h-2 bg-white/5 rounded-full overflow-hidden">
                    <div class="h-full bg-indigo-500" style="width: {{ min(($post_stats['comments'] / max($post_stats['total'] ?: 1, 1)) * 20, 100) }}%"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
    <div class="glass p-6 rounded-3xl">
        <p class="text-slate-400 text-xs font-bold uppercase mb-2">Total Comments</p>
        <h4 class="text-3xl font-bold">{{ number_format($post_stats['comments']) }}</h4>
    </div>
    <div class="glass p-6 rounded-3xl">
        <p class="text-slate-400 text-xs font-bold uppercase mb-2">Total Likes</p>
        <h4 class="text-3xl font-bold">{{ number_format($post_stats['likes']) }}</h4>
    </div>
</div>
@endsection
