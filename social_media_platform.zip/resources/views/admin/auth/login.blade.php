<!DOCTYPE html>
<html lang="en" class="dark">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Admin Login — {{ config('app.name') }}</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: { sans: ['Outfit', 'sans-serif'] }
                }
            }
        }
    </script>

    <style>
        body {
            font-family: 'Outfit', sans-serif;
            background: #0a0b10;
            overflow: hidden;
        }
        .glow-ring {
            box-shadow: 0 0 80px rgba(99, 102, 241, 0.15), 0 0 200px rgba(99, 102, 241, 0.05);
        }
        .login-input {
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid rgba(255, 255, 255, 0.08);
            transition: all 0.3s ease;
        }
        .login-input:focus {
            background: rgba(255, 255, 255, 0.06);
            border-color: #6366f1;
            box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.15);
        }
        @keyframes float {
            0%, 100% { transform: translateY(0px) rotate(0deg); }
            50% { transform: translateY(-20px) rotate(3deg); }
        }
        .float-anim { animation: float 6s ease-in-out infinite; }
        @keyframes pulse-slow {
            0%, 100% { opacity: 0.3; }
            50% { opacity: 0.6; }
        }
        .pulse-bg { animation: pulse-slow 4s ease-in-out infinite; }
    </style>
</head>
<body class="antialiased min-h-screen flex items-center justify-center relative">

    <!-- Background Effects -->
    <div class="absolute inset-0 overflow-hidden">
        <div class="absolute top-1/4 left-1/4 w-96 h-96 bg-indigo-600/10 rounded-full blur-3xl pulse-bg"></div>
        <div class="absolute bottom-1/4 right-1/4 w-80 h-80 bg-purple-600/10 rounded-full blur-3xl pulse-bg" style="animation-delay: 2s;"></div>
        <div class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] border border-white/[0.02] rounded-full"></div>
        <div class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] border border-white/[0.01] rounded-full"></div>
    </div>

    <!-- Login Card -->
    <div class="relative z-10 w-full max-w-md px-6">
        <div class="glow-ring rounded-3xl p-10" style="background: rgba(15, 17, 23, 0.85); backdrop-filter: blur(40px); border: 1px solid rgba(255,255,255,0.06);">
            
            <!-- Logo -->
            <div class="text-center mb-10">
                <div class="inline-flex items-center justify-center w-16 h-16 bg-indigo-600 rounded-2xl mb-5 float-anim shadow-lg shadow-indigo-500/20">
                    <svg class="w-9 h-9 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
                    </svg>
                </div>
                <h1 class="text-3xl font-extrabold text-white tracking-tight">Admin<span class="text-indigo-500">Panel</span></h1>
                <p class="text-slate-500 text-sm mt-2">Authorized personnel only</p>
            </div>

            <!-- Error Messages -->
            @if($errors->any())
                <div class="mb-6 p-4 rounded-2xl text-sm font-medium" style="background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.2); color: #f87171;">
                    @foreach($errors->all() as $error)
                        <p>{{ $error }}</p>
                    @endforeach
                </div>
            @endif

            <!-- Login Form -->
            <form method="POST" action="{{ route('admin.login.submit') }}">
                @csrf

                <div class="space-y-5">
                    <div>
                        <label class="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Email Address</label>
                        <input type="email" name="email" value="{{ old('email') }}" required autofocus
                               class="login-input w-full rounded-xl px-4 py-3.5 text-white placeholder-slate-600 outline-none text-sm"
                               placeholder="admin@connecthub.com">
                    </div>

                    <div>
                        <label class="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Password</label>
                        <input type="password" name="password" required
                               class="login-input w-full rounded-xl px-4 py-3.5 text-white placeholder-slate-600 outline-none text-sm"
                               placeholder="••••••••••">
                    </div>

                    <button type="submit"
                            class="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-4 rounded-xl transition-all duration-300 transform hover:scale-[1.02] active:scale-[0.98] shadow-lg shadow-indigo-500/25 text-sm uppercase tracking-wider mt-2">
                        Authenticate
                    </button>
                </div>
            </form>

            <div class="mt-8 text-center">
                <a href="{{ url('/') }}" class="text-xs text-slate-600 hover:text-slate-400 transition-colors">
                    ← Back to {{ config('app.name') }}
                </a>
            </div>
        </div>

        <p class="text-center text-[10px] text-slate-700 mt-6 uppercase tracking-widest">
            Secure Admin Access · {{ config('app.name') }} © {{ date('Y') }}
        </p>
    </div>
</body>
</html>
