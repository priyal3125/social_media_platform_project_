@extends('layouts.admin')

@section('header', 'Overview')

@section('content')
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
    <!-- Stats Cards -->
    <div class="glass p-6 rounded-3xl border-l-4 border-indigo-500">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-slate-400 text-sm font-medium uppercase mb-1">Total Users</p>
                <h3 class="text-3xl font-bold">{{ number_format($stats['total_users']) }}</h3>
            </div>
            <div class="p-3 bg-indigo-500/10 rounded-2xl">
                <svg class="w-8 h-8 text-indigo-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path></svg>
            </div>
        </div>
    </div>
    
    <div class="glass p-6 rounded-3xl border-l-4 border-emerald-500">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-slate-400 text-sm font-medium uppercase mb-1">Active Posts</p>
                <h3 class="text-3xl font-bold">{{ number_format($stats['total_posts']) }}</h3>
            </div>
            <div class="p-3 bg-emerald-500/10 rounded-2xl">
                <svg class="w-8 h-8 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10l4 4v10a2 2 0 01-2 2zM14 2v4h4"></path></svg>
            </div>
        </div>
    </div>

    <div class="glass p-6 rounded-3xl border-l-4 border-rose-500">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-slate-400 text-sm font-medium uppercase mb-1">Pending Reports</p>
                <h3 class="text-3xl font-bold">{{ number_format($stats['pending_reports']) }}</h3>
            </div>
            <div class="p-3 bg-rose-500/10 rounded-2xl">
                <svg class="w-8 h-8 text-rose-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path></svg>
            </div>
        </div>
    </div>

    <div class="glass p-6 rounded-3xl border-l-4 border-amber-500">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-slate-400 text-sm font-medium uppercase mb-1">Audit Logs</p>
                <h3 class="text-3xl font-bold">{{ number_format($recent_actions->count()) }}</h3>
            </div>
            <div class="p-3 bg-amber-500/10 rounded-2xl">
                <svg class="w-8 h-8 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 8v4l3 2m6-2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            </div>
        </div>
    </div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
    <!-- Recent Reports -->
    <div class="glass rounded-3xl overflow-hidden">
        <div class="p-6 border-b border-white/5 flex justify-between items-center">
            <h2 class="text-lg font-bold">Recent Reports</h2>
            <a href="{{ route('admin.moderation.index') }}" class="text-xs font-semibold text-indigo-400 hover:text-indigo-300 uppercase tracking-wider">View All</a>
        </div>
        <div class="divide-y divide-white/5">
            @foreach($recent_reports as $report)
            <div class="p-6 flex items-start space-x-4">
                <div class="w-10 h-10 rounded-full bg-rose-500/10 flex items-center justify-center flex-shrink-0">
                    <svg class="w-6 h-6 text-rose-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path></svg>
                </div>
                <div class="flex-1 min-w-0">
                    <p class="text-sm font-semibold">Report by {{ $report->reporter->name }}</p>
                    <p class="text-sm text-slate-400 mt-1 italic">"{{ Str::limit($report->reason, 100) }}"</p>
                    <div class="mt-3 flex items-center space-x-2">
                        <span class="px-2 py-0.5 rounded text-[10px] font-bold uppercase {{ $report->status === 'pending' ? 'bg-rose-500/10 text-rose-500' : 'bg-blue-500/10 text-blue-500' }}">
                            {{ $report->status }}
                        </span>
                        <span class="text-[10px] text-slate-500 tracking-tighter">{{ $report->created_at->diffForHumans() }}</span>
                    </div>
                </div>
            </div>
            @endforeach
            @if($recent_reports->isEmpty())
                <div class="p-12 text-center text-slate-500 italic">No recent reports.</div>
            @endif
        </div>
    </div>

    <!-- Audit Logs -->
    <div class="glass rounded-3xl overflow-hidden">
        <div class="p-6 border-b border-white/5 flex justify-between items-center">
            <h2 class="text-lg font-bold">Audit Logs</h2>
            <a href="#" class="text-xs font-semibold text-indigo-400 hover:text-indigo-300 uppercase tracking-wider">View All</a>
        </div>
        <div class="p-6">
            <div class="flow-root">
                <ul role="list" class="-mb-8">
                    @foreach($recent_actions as $log)
                    <li>
                        <div class="relative pb-8">
                            @if(!$loop->last)
                            <span class="absolute top-4 left-4 -ml-px h-full w-0.5 bg-white/5" aria-hidden="true"></span>
                            @endif
                            <div class="relative flex space-x-3">
                                <div>
                                    <span class="h-8 w-8 rounded-full bg-slate-700 flex items-center justify-center ring-4 ring-[#0f1117]">
                                        <svg class="h-5 w-5 text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 8v4l3 2m6-2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                                    </span>
                                </div>
                                <div class="flex min-w-0 flex-1 justify-between space-x-4 pt-1.5">
                                    <div>
                                        <p class="text-sm text-slate-300">
                                            <span class="font-medium text-white">{{ $log->admin->name }}</span> 
                                            {{ str_replace('_', ' ', $log->action) }}
                                        </p>
                                    </div>
                                    <div class="whitespace-nowrap text-right text-xs text-slate-500">
                                        <time datetime="{{ $log->created_at }}">{{ $log->created_at->diffForHumans() }}</time>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                    @endforeach
                    @if($recent_actions->isEmpty())
                        <div class="text-center text-slate-500 italic py-12">No recent audit logs.</div>
                    @endif
                </ul>
            </div>
        </div>
    </div>
</div>
@endsection
