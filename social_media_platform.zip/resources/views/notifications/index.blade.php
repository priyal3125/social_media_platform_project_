<x-app-layout>
    <div class="row g-4 justify-content-center">
        <div class="col-12 col-lg-7">
            <div class="ig-card p-3 mb-3 d-flex align-items-center justify-content-between">
                <div class="fw-semibold">Notifications</div>
                @if($unreadCount > 0)
                    <form action="{{ route('notifications.readAll') }}" method="POST" class="m-0">
                        @csrf
                        <button type="submit" class="btn btn-sm btn-light ig-btn">Mark all read</button>
                    </form>
                @endif
            </div>

            @if($notifications->isEmpty())
                <div class="ig-card p-5 text-center ig-muted">
                    <div class="mb-3">
                        <i class="fa-regular fa-bell fa-3x"></i>
                    </div>
                    <div class="fw-semibold">No notifications</div>
                </div>
            @else
                <div class="ig-card">
                    <div class="list-group list-group-flush">
                        @foreach($notifications as $notification)
                            <a href="{{ route('notifications.open', $notification) }}" class="list-group-item list-group-item-action border-0 py-3">
                                <div class="d-flex align-items-start justify-content-between gap-3">
                                    <div class="min-w-0">
                                        <div class="{{ $notification->is_read ? '' : 'fw-semibold' }} text-truncate">
                                            {{ $notification->message ?: ($notification->title ?: 'Notification') }}
                                        </div>
                                        <div class="text-muted small">{{ $notification->created_at->diffForHumans() }}</div>
                                    </div>
                                    @if(!$notification->is_read)
                                        <span class="badge bg-primary rounded-pill align-self-center">New</span>
                                    @endif
                                </div>
                            </a>
                        @endforeach
                    </div>
                </div>

                <div class="mt-4">
                    {{ $notifications->links('pagination::bootstrap-5') }}
                </div>
            @endif
        </div>
    </div>
</x-app-layout>
