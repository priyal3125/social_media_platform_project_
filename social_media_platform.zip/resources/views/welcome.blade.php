<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>{{ config('app.name', 'ConnectHub') }} — Social Excellence</title>

        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
        <link rel="stylesheet" href="{{ asset('css/instagram.css') }}">

        <style>
            .landing-hero {
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 100px 20px;
                position: relative;
                overflow: hidden;
            }

            .vibrant-blob {
                position: absolute;
                width: 600px;
                height: 600px;
                background: linear-gradient(135deg, hsla(250, 100%, 65%, 0.2), hsla(330, 100%, 65%, 0.2));
                filter: blur(80px);
                border-radius: 50%;
                z-index: -1;
                animation: float 20s infinite alternate ease-in-out;
            }

            @keyframes float {
                from { transform: translate(-10%, -10%); }
                to { transform: translate(10%, 10%) scale(1.1); }
            }

            .main-title {
                font-family: 'Outfit', sans-serif;
                font-weight: 800;
                font-size: clamp(3.5rem, 8vw, 6rem);
                line-height: 0.9;
                letter-spacing: -3px;
                margin-bottom: 32px;
            }

            .glass-stat-card {
                background: rgba(255, 255, 255, 0.4);
                backdrop-filter: var(--glass);
                border: 1px solid var(--border-light);
                padding: 24px;
                border-radius: var(--radius-lg);
                box-shadow: var(--shadow-md);
            }

            .feature-pill {
                display: inline-flex;
                align-items: center;
                gap: 8px;
                padding: 8px 20px;
                background: white;
                border-radius: 99px;
                box-shadow: var(--shadow-sm);
                font-weight: 600;
                font-size: 0.9rem;
                margin-bottom: 24px;
            }
        </style>
    </head>
    <body class="bg-app">
        <div class="vibrant-blob" style="top: -100px; left: -100px;"></div>
        <div class="vibrant-blob" style="bottom: -100px; right: -100px; animation-delay: -10s;"></div>

        <nav class="navbar navbar-expand-lg fixed-top px-lg-5 pt-4">
            <div class="container-fluid">
                <a class="navbar-brand fw-bold fs-3 text-primary" href="#" style="font-family: 'Outfit'; letter-spacing: -1px;">
                    <i class="fa-solid fa-earth-americas"></i> ConnectHub
                </a>
                <div class="ms-auto d-flex gap-3">
                    @auth
                        <a href="{{ route('home') }}" class="btn btn-primary ig-btn px-4 py-2">Go to Feed</a>
                    @else
                        <a href="{{ route('login') }}" class="btn btn-light ig-btn px-4 py-2">Login</a>
                        <a href="{{ route('register') }}" class="btn btn-primary ig-btn px-4 py-2">Get Started</a>
                    @endauth
                </div>
            </div>
        </nav>

        <section class="landing-hero">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-7 text-center text-lg-start">
                        <div class="feature-pill text-primary">
                            <i class="fa-solid fa-bolt"></i>
                            The Future of Connection is Here
                        </div>
                        <h1 class="main-title">Capture <br> Every <br> <span class="text-primary">Moment.</span></h1>
                        <p class="fs-4 text-muted mb-5 max-width-600">
                            A refined social experience built for the modern era. No clutter, no noise, just genuine connection.
                        </p>
                        
                        <div class="d-flex flex-wrap gap-3 justify-content-center justify-content-lg-start">
                            <a href="{{ route('register') }}" class="btn btn-primary ig-btn px-5 py-3 fs-5 shadow-lg">Start Sharing — It's Free</a>
                            <a href="#features" class="btn btn-light ig-btn px-5 py-3 fs-5">Explore Design</a>
                        </div>
                    </div>
                    
                    <div class="col-lg-5 d-none d-lg-block">
                        <div class="position-relative">
                            <div class="ig-card p-4 shadow-lg rotate-3" style="transform: rotate(6deg); max-width: 380px; margin-left: auto;">
                                <div class="d-flex align-items-center gap-3 mb-3">
                                    <div class="ig-story-ring" style="width: 48px; height: 48px; padding: 2px;">
                                        <img src="https://i.pravatar.cc/150?u=1" style="width: 40px; height: 40px;">
                                    </div>
                                    <div>
                                        <div class="fw-bold small">alex_design</div>
                                        <div class="ig-muted" style="font-size: 10px;">Tokyo, Japan</div>
                                    </div>
                                </div>
                                <div class="bg-light rounded-4 overflow-hidden mb-3" style="aspect-ratio: 1/1;">
                                    <img src="https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=400&q=80" class="w-100 h-100 object-fit-cover">
                                </div>
                                <div class="d-flex gap-3 mb-2 text-primary">
                                    <i class="fa-regular fa-heart"></i>
                                    <i class="fa-regular fa-comment"></i>
                                    <i class="fa-regular fa-paper-plane"></i>
                                </div>
                                <div class="small fw-bold">1,248 likes</div>
                            </div>
                            
                            <div class="glass-stat-card position-absolute" style="bottom: -40px; left: 0; z-index: 2;">
                                <div class="d-flex align-items-center gap-3">
                                    <div class="bg-primary text-white rounded-circle p-3 d-flex align-items-center justify-content-center" style="width: 50px; height: 50px;">
                                        <i class="fa-solid fa-users fs-5"></i>
                                    </div>
                                    <div>
                                        <div class="fw-bold fs-5">250k+</div>
                                        <div class="small text-muted">Active Explorers</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section id="features" class="container py-5 mb-5">
            <div class="row g-4 justify-content-center">
                <div class="col-md-4">
                    <div class="ig-card p-4 h-100 border-0 shadow-sm text-center">
                        <div class="text-primary mb-3"><i class="fa-solid fa-wand-magic-sparkles fa-3x"></i></div>
                        <h4 class="fw-bold">Modern Visuals</h4>
                        <p class="text-muted small">Glassmorphism and HSL-based colors for a premium, high-end feel.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="ig-card p-4 h-100 border-0 shadow-sm text-center">
                        <div class="text-accent mb-3" style="color: var(--accent);"><i class="fa-solid fa-bolt-lightning fa-3x"></i></div>
                        <h4 class="fw-bold">Lightning Fast</h4>
                        <p class="text-muted small">Optimized interactions and smooth animations for a seamless experience.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="ig-card p-4 h-100 border-0 shadow-sm text-center">
                        <div class="text-success mb-3"><i class="fa-solid fa-shield-halved fa-3x"></i></div>
                        <h4 class="fw-bold">Secure by Design</h4>
                        <p class="text-muted small">State-of-the-art protection for your data and your digital identity.</p>
                    </div>
                </div>
            </div>
        </section>

        <footer class="py-5 text-center text-muted small border-top">
            <div class="container">
                <div class="d-flex justify-content-center gap-4 mb-4">
                    <a href="#" class="text-muted text-decoration-none">About</a>
                    <a href="#" class="text-muted text-decoration-none">Terms</a>
                    <a href="#" class="text-muted text-decoration-none">Privacy</a>
                    <a href="#" class="text-muted text-decoration-none">Developers</a>
                </div>
                <p>© {{ date('Y') }} ConnectHub Global. Crafted for Perfection.</p>
            </div>
        </footer>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    </body>
</html>
