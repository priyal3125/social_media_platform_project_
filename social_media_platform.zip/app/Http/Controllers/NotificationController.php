<?php

namespace App\Http\Controllers;

use App\Models\Notification;
use Illuminate\Http\Request;

class NotificationController extends Controller
{
    public function index()
    {
        $unreadCount = auth()->user()
            ->notifications()
            ->where('is_read', false)
            ->count();

        $notifications = auth()->user()
            ->notifications()
            ->latest()
            ->paginate(20);

        return view('notifications.index', compact('notifications', 'unreadCount'));
    }

    public function readAll()
    {
        auth()->user()
            ->notifications()
            ->where('is_read', false)
            ->update(['is_read' => true]);

        return redirect()->back();
    }

    public function open(Notification $notification)
    {
        if ($notification->user_id !== auth()->id()) {
            abort(403);
        }

        if (!$notification->is_read) {
            $notification->update(['is_read' => true]);
        }

        $url = $notification->data['url'] ?? route('home', absolute: false);

        return redirect($url);
    }
}
