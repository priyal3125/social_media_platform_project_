<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Message;
use App\Models\Notification;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class MessageController extends Controller
{
    public function index()
    {
        $authId = auth()->id();

        // Retrieve all users who have exchanged messages with auth user
        $exchangedIds = Message::where('sender_id', $authId)
            ->orWhere('receiver_id', $authId)
            ->get(['sender_id', 'receiver_id'])
            ->flatMap(fn($msg) => [$msg->sender_id, $msg->receiver_id])
            ->unique()
            ->reject(fn($id) => $id === $authId);

        // Retrieve followers and followed users
        $followerIds = auth()->user()->followers()->pluck('follower_id');
        $followingIds = auth()->user()->following()->pluck('following_id');

        $allUserIds = $exchangedIds->concat($followerIds)->concat($followingIds)->unique();
        
        $chatUsers = User::whereIn('id', $allUserIds)->get()->map(function($user) use ($authId) {
            $user->last_message = Message::where(function($q) use ($authId, $user) {
                    $q->where('sender_id', $authId)->where('receiver_id', $user->id);
                })->orWhere(function($q) use ($authId, $user) {
                    $q->where('sender_id', $user->id)->where('receiver_id', $authId);
                })->latest()->first();

            $user->unread_count = Message::where('sender_id', $user->id)
                ->where('receiver_id', $authId)
                ->where('is_seen', false)
                ->count();

            return $user;
        })->sortByDesc(fn($u) => $u->last_message?->created_at)->values();

        return view('messages.index', compact('chatUsers'));
    }

    public function chat(User $user)
    {
        $authId = auth()->id();

        // Mark incoming messages from this user as seen
        Message::where('sender_id', $user->id)
            ->where('receiver_id', $authId)
            ->where('is_seen', false)
            ->update(['is_seen' => true]);

        // Get messaging history
        $messages = Message::where(function($q) use ($authId, $user) {
                $q->where('sender_id', $authId)->where('receiver_id', $user->id);
            })->orWhere(function($q) use ($authId, $user) {
                $q->where('sender_id', $user->id)->where('receiver_id', $authId);
            })->orderBy('created_at', 'asc')->get();

        // Refresh list of chat users for sidebar
        $exchangedIds = Message::where('sender_id', $authId)
            ->orWhere('receiver_id', $authId)
            ->get(['sender_id', 'receiver_id'])
            ->flatMap(fn($msg) => [$msg->sender_id, $msg->receiver_id])
            ->unique()
            ->reject(fn($id) => $id === $authId);

        $followerIds = auth()->user()->followers()->pluck('follower_id');
        $followingIds = auth()->user()->following()->pluck('following_id');

        $allUserIds = $exchangedIds->concat($followerIds)->concat($followingIds)->unique();
        
        $chatUsers = User::whereIn('id', $allUserIds)->get()->map(function($u) use ($authId) {
            $u->last_message = Message::where(function($q) use ($authId, $u) {
                    $q->where('sender_id', $authId)->where('receiver_id', $u->id);
                })->orWhere(function($q) use ($authId, $u) {
                    $q->where('sender_id', $u->id)->where('receiver_id', $authId);
                })->latest()->first();

            $u->unread_count = Message::where('sender_id', $u->id)
                ->where('receiver_id', $authId)
                ->where('is_seen', false)
                ->count();

            return $u;
        })->sortByDesc(fn($u) => $u->last_message?->created_at)->values();

        return view('messages.index', compact('chatUsers', 'user', 'messages'));
    }

    public function send(Request $request, User $user)
    {
        $request->validate([
            'message' => 'nullable|string|max:5000',
            'image' => 'nullable|image|max:5120',
        ]);

        if (!$request->message && !$request->hasFile('image')) {
            return response()->json(['error' => 'Message cannot be empty.'], 422);
        }

        $imgPath = null;
        if ($request->hasFile('image')) {
            $imgPath = $request->file('image')->store('messages', 'public');
        }

        $message = Message::create([
            'sender_id' => auth()->id(),
            'receiver_id' => $user->id,
            'message' => $request->message,
            'image' => $imgPath,
            'is_seen' => false,
        ]);

        if ($user->id !== auth()->id()) {
            $actor = auth()->user();
            $actorName = $actor->username ?: $actor->name;
            $preview = trim((string) $request->message);
            if ($preview !== '') {
                $preview = Str::limit($preview, 80);
            }

            Notification::create([
                'user_id' => $user->id,
                'type' => 'message',
                'title' => 'New message',
                'message' => $actorName . ' sent you a message' . ($preview !== '' ? ': ' . $preview : '.'),
                'data' => [
                    'url' => route('messages.chat', $actor->id, absolute: false),
                    'actor_id' => $actor->id,
                    'message_id' => $message->id,
                ],
            ]);
        }

        return response()->json([
            'success' => true,
            'message' => $message,
            'html' => view('messages.partials.message_bubble', ['msg' => $message])->render()
        ]);
    }

    public function poll(User $user)
    {
        $authId = auth()->id();

        // Get unseen incoming messages
        $newMessages = Message::where('sender_id', $user->id)
            ->where('receiver_id', $authId)
            ->where('is_seen', false)
            ->orderBy('created_at', 'asc')
            ->get();

        $html = '';
        if ($newMessages->isNotEmpty()) {
            foreach ($newMessages as $msg) {
                $html .= view('messages.partials.message_bubble', ['msg' => $msg])->render();
            }

            // Mark these polled messages as seen
            Message::where('sender_id', $user->id)
                ->where('receiver_id', $authId)
                ->where('is_seen', false)
                ->update(['is_seen' => true]);
        }

        return response()->json([
            'newMessages' => $newMessages,
            'html' => $html
        ]);
    }
}
