<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\Http\Request;

class ReelsController extends Controller
{
    public function create()
    {
        return view('reels.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'nullable|string|max:255',
            'content' => 'nullable|string|max:5000',
            'video' => 'required|file|mimes:mp4,mov,webm|max:51200',
        ]);

        $post = new Post();
        $post->user_id = auth()->id();
        $post->title = $request->title;
        $post->content = $request->content;
        $post->privacy = 'public';

        $path = $request->file('video')->store('posts/videos', 'public');
        $post->video = $path;

        $post->save();

        return redirect()->route('reels.index')->with('success', 'Reel uploaded successfully!');
    }
}

