<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Report;
use App\Services\ModerationService;
use Illuminate\Http\Request;

class ModerationController extends Controller
{
    protected $moderationService;

    public function __construct(ModerationService $moderationService)
    {
        $this->moderationService = $moderationService;
    }

    public function index()
    {
        $reports = Report::with(['reporter', 'reportable'])->latest()->paginate(20);
        return view('admin.moderation.index', compact('reports'));
    }

    public function update(Request $request, Report $report)
    {
        $request->validate([
            'status' => 'required|in:pending,under_review,approved,removed',
            'admin_notes' => 'nullable|string',
        ]);

        $this->moderationService->updateStatus($report, $request->status, $request->admin_notes);

        return back()->with('success', 'Report status updated successfully.');
    }
}
