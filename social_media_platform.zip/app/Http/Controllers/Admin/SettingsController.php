<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class SettingsController extends Controller
{
    public function index()
    {
        // Sample settings data
        $settings = [
            'site_name' => config('app.name'),
            'maintenance_mode' => false,
            'require_2fa' => true,
            'can_register' => true,
        ];

        return view('admin.settings.index', compact('settings'));
    }

    public function update(Request $request)
    {
        // In a real app, you would save these to a 'settings' table or .env
        return back()->with('success', 'Settings updated successfully.');
    }
}
