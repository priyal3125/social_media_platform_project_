<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Report;
use Illuminate\Http\Request;

class ReportsOverviewController extends Controller
{
    public function index()
    {
        $stats = [
            'total' => Report::count(),
            'pending' => Report::where('status', 'pending')->count(),
            'resolved' => Report::whereIn('status', ['approved', 'removed'])->count(),
        ];

        $reports = Report::with(['reporter', 'reportable'])->latest()->paginate(20);

        return view('admin.reports.index', compact('stats', 'reports'));
    }
}
