<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Post;
use App\Models\Report;
use App\Models\AuditLog;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index()
    {
        $stats = [
            'total_users' => User::count(),
            'total_posts' => Post::count(),
            'pending_reports' => Report::where('status', 'pending')->count(),
            'total_reports' => Report::count(),
        ];

        $recent_actions = AuditLog::with('admin')->latest()->take(10)->get();
        $recent_reports = Report::with(['reporter', 'reportable'])->latest()->take(5)->get();

        return view('admin.dashboard', compact('stats', 'recent_actions', 'recent_reports'));
    }
}
