<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Post;
use App\Http\Requests\ProfileUpdateRequest;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\View\View;

class ProfileController extends Controller
{
    public function show($username)
    {
        $user = User::where('username', $username)->orWhere('id', $username)->firstOrFail();
        $tab = request()->string('tab')->toString();
        if (!in_array($tab, ['posts', 'reels'], true)) {
            $tab = 'posts';
        }

        $postsCount = Post::where('user_id', $user->id)->whereNull('video')->count();
        $reelsCount = Post::where('user_id', $user->id)->whereNotNull('video')->count();

        $query = Post::with(['user', 'comments.user', 'likes'])
            ->where('user_id', $user->id)
            ->latest();

        if ($tab === 'reels') {
            $query->whereNotNull('video');
        } else {
            $query->whereNull('video');
        }

        $posts = $query->paginate(10)->withQueryString();

        return view('profile.show', compact('user', 'posts', 'tab', 'postsCount', 'reelsCount'));
    }

    /**
     * Display the user's profile form.
     */
    public function edit(Request $request): View
    {
        return view('profile.edit', [
            'user' => $request->user(),
        ]);
    }

    /**
     * Update the user's profile information.
     */
    public function update(ProfileUpdateRequest $request): RedirectResponse
    {
        $user = $request->user();
        
        $data = $request->validated();
        $data['is_private'] = $request->has('is_private');
        
        if ($request->hasFile('profile_photo')) {
            $data['profile_photo'] = $request->file('profile_photo')->store('profiles', 'public');
        }
        if ($request->hasFile('cover_photo')) {
            $data['cover_photo'] = $request->file('cover_photo')->store('covers', 'public');
        }

        $user->fill($data);

        if ($user->isDirty('email')) {
            $user->email_verified_at = null;
        }

        $user->save();

        return Redirect::route('profile.edit')->with('status', 'profile-updated');
    }

    /**
     * Delete the user's account.
     */
    public function destroy(Request $request): RedirectResponse
    {
        $request->validateWithBag('userDeletion', [
            'password' => ['required', 'current_password'],
        ]);

        $user = $request->user();

        Auth::logout();

        $user->delete();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return Redirect::to('/');
    }
}
