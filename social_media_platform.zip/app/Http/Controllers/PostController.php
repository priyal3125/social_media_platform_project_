<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\Http\Request;

class PostController extends Controller
{
    public function view(Post $post)
    {
        $post->increment('views_count');

        return response()->json([
            'views_count' => $post->fresh()->views_count
        ]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'nullable|string|max:255',
            'content' => 'nullable|string|max:5000',
            'image' => 'nullable|image|max:5120',
            'video' => 'nullable|file|mimes:mp4,mov,webm|max:51200',
            'privacy' => 'required|in:public,friends,private'
        ]);

        if (!$request->filled('title') && !$request->filled('content') && !$request->hasFile('image') && !$request->hasFile('video')) {
            return back()->withErrors([
                'content' => 'Please add a title, caption, image, or video.'
            ])->withInput();
        }

        $post = new Post();
        $post->user_id = auth()->id();
        $post->title = $request->input('title');
        $post->content = $request->input('content');
        $post->privacy = $request->privacy;

        if ($request->hasFile('image')) {
            $path = $request->file('image')->store('posts', 'public');
            $post->image = $path;
        }

        if ($request->hasFile('video')) {
            $path = $request->file('video')->store('posts/videos', 'public');
            $post->video = $path;
        }

        $post->save();

        return redirect()->back()->with('success', 'Post created successfully!');
    }

    public function destroy(Post $post)
    {
        if (auth()->id() !== $post->user_id) {
            abort(403);
        }

        $post->delete();

        return redirect()->back()->with('success', 'Post deleted successfully!');
    }
}
