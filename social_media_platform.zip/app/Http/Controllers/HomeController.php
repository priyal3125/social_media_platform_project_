<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index()
    {
        $user = auth()->user();
        
        // Fetch posts from user and people they follow
        $followingIds = $user->following()->pluck('users.id')->toArray();
        $followingIds[] = $user->id; // Include own posts

        $posts = Post::with(['user', 'comments.user', 'likes'])
                     ->whereIn('user_id', $followingIds)
                     ->latest()
                     ->paginate(10);

        // Fetch active stories (last 24 hours) grouped by user
        $activeStories = \App\Models\Story::with('user')
            ->whereIn('user_id', $followingIds)
            ->where('expires_at', '>', now())
            ->latest()
            ->get()
            ->groupBy('user_id');

        // Fetch suggested users (not followed yet)
        $suggestedUsers = \App\Models\User::whereNotIn('id', $followingIds)
            ->where('id', '!=', $user->id)
            ->inRandomOrder()
            ->take(5)
            ->get();

        return view('home', compact('posts', 'activeStories', 'suggestedUsers'));
    }

    public function explore(Request $request)
    {
        $query = Post::with(['user', 'likes', 'comments'])
                     ->where('privacy', 'public')
                     ->select('posts.*')
                     ->distinct();

        // 1. Filter by Search Query
        if ($request->filled('q')) {
            $q = $request->q;
            $query->where(function ($sub) use ($q) {
                $sub->where('title', 'like', "%{$q}%")
                    ->orWhere('content', 'like', "%{$q}%")
                    ->orWhere('hashtags', 'like', "%{$q}%")
                    ->orWhereHas('user', fn ($u) => $u->where('name', 'like', "%{$q}%")
                        ->orWhere('username', 'like', "%{$q}%"));
            });
        }

        // 2. Filter by Category
        if ($request->filled('category') && $request->category !== 'All') {
            $query->where('category', $request->category);
        }

        // Fetch a larger pool so de-duplication still yields enough cards
        $rawPosts = $query->orderByDesc('created_at')->limit(200)->get();

        // 3. De-duplicate by image path
        $seen      = [];
        $unique    = $rawPosts->filter(function ($post) use (&$seen) {
            $key = $post->image ?: ('placeholder-' . $post->id);
            if (isset($seen[$key])) {
                return false;
            }
            $seen[$key] = true;
            return true;
        });

        // 4. Shuffle for discovery randomness (only when not searching)
        if (!$request->filled('q') && !$request->filled('category')) {
            $unique = $unique->shuffle();
        }

        // 5. Manual pagination
        $page     = (int) ($request->page ?? 1);
        $perPage  = 24;
        $total    = $unique->count();
        $items    = $unique->forPage($page, $perPage)->values();

        $posts = new \Illuminate\Pagination\LengthAwarePaginator(
            $items,
            $total,
            $perPage,
            $page,
            ['path' => $request->url(), 'query' => $request->query()]
        );

        // 6. Handle AJAX response
        if ($request->ajax()) {
            $categoryKeyword = [
                'Travel'  => 'travel,landscape',
                'Food'    => 'food,cooking',
                'Nature'  => 'nature,forest',
                'Art'     => 'art,painting',
                'Fashion' => 'fashion,style',
                'Tech'    => 'technology,computer',
                'People'  => 'people,portrait',
            ];

            $html = "";
            foreach ($posts as $post) {
                $keyword = $categoryKeyword[$post->category] ?? 'photography';
                $imgUrl  = $post->image
                    ? asset('storage/' . $post->image)
                    : 'https://loremflickr.com/800/600/' . urlencode($keyword) . '?lock=' . $post->id;
                $avatar = $post->user->profile_photo ? asset('storage/' . $post->user->profile_photo) : 'https://ui-avatars.com/api/?name=' . urlencode($post->user->name) . '&background=random&size=64';
                $username = $post->user->username ?? $post->user->name;
                $title = e($post->title ?: $post->content ?: $username);
                $views = number_format($post->views_count ?? 0);
                $likes = $post->likes->count();
                $imgH = match($post->id % 3) { 0 => '220px', 1 => '300px', default => '260px' };
                $videoUrl = $post->video ? asset('storage/' . $post->video) : '';

                $html .= "
                <div class='masonry-card' 
                     data-trigger-post-modal 
                     data-post-id='{$post->id}'
                     data-post-image-grid='{$imgUrl}'
                     data-post-image-modal='{$imgUrl}'
                     data-post-video='{$videoUrl}'
                     data-post-profile='{$avatar}'
                     data-post-user='{$username}'
                     data-post-views='{$post->views_count}'
                     data-post-caption='".e($post->content)."'
                     data-post-title='".e($post->title)."'
                     role='button' tabindex='0'>";
                
                if($videoUrl) {
                    $html .= "<span class='video-badge'><i class='fa-solid fa-clapperboard me-1'></i>Reel</span>";
                    $html .= "<video src='{$videoUrl}' style='height: {$imgH};' muted playsinline preload='metadata'></video>";
                } else {
                    $fallback = 'https://picsum.photos/seed/fallback-' . $post->id . '/800/600';
                    $html .= "<img src='{$imgUrl}'
                                   style='height: {$imgH}; width: 100%; object-fit: cover; display: block;'
                                   alt='{$title}'
                                   onerror=\"this.onerror=null;this.src='{$fallback}';\">";
                }

                $html .= "
                    <div class='masonry-overlay'>
                        <div class='card-user'>@{$username}</div>
                        <div class='card-title'>".\Illuminate\Support\Str::limit($title, 60)."</div>
                        <div class='card-meta'>
                            <span><i class='fa-solid fa-eye me-1'></i>{$views}</span>
                            <span>·</span>
                            <span><i class='fa-solid fa-heart me-1' style='color:#ff6b8a;'></i>{$likes}</span>
                        </div>
                    </div>
                </div>";
            }
            return response()->json(['html' => $html, 'total' => $total]);
        }

        return view('explore', compact('posts'));
    }

    public function reels()
    {
        $scope = request()->string('scope')->toString();
        $user = auth()->user();

        if ($scope === '') {
            $scope = 'following';
        }

        $query = Post::with(['user', 'likes', 'comments.user'])
            ->whereNotNull('video')
            ->where('privacy', 'public')
            ->latest();

        if ($scope === 'following') {
            $followingIds = $user->following()->pluck('users.id')->toArray();
            $followingIds[] = $user->id;
            $query->whereIn('user_id', $followingIds);
        }

        $reels = $query->take(60)->get();

        return view('reels.index', compact('reels', 'scope'));
    }
}
