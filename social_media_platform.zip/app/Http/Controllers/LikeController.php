<?php

namespace App\Http\Controllers;

use App\Models\Post;
use App\Models\Like;
use App\Models\Notification;
use Illuminate\Http\Request;

class LikeController extends Controller
{
    public function toggleLike(Post $post)
    {
        $actor = auth()->user();
        $user_id = $actor->id;
        
        $like = Like::where('post_id', $post->id)->where('user_id', $user_id)->first();
        
        if ($like) {
            $like->delete();
            $status = 'unliked';
        } else {
            Like::create([
                'post_id' => $post->id,
                'user_id' => $user_id
            ]);
            $status = 'liked';

            if ($post->user_id !== $user_id) {
                $actorName = $actor->username ?: $actor->name;
                $target = $post->video ? 'reel' : 'post';
                $url = $post->video
                    ? route('reels.index', ['scope' => 'all'], absolute: false) . '#reel-' . $post->id
                    : route('home', absolute: false) . '#post-' . $post->id;

                Notification::create([
                    'user_id' => $post->user_id,
                    'type' => 'like',
                    'title' => 'New like',
                    'message' => $actorName . ' liked your ' . $target . '.',
                    'data' => [
                        'url' => $url,
                        'actor_id' => $user_id,
                        'post_id' => $post->id,
                    ],
                ]);
            }
        }

        return response()->json([
            'status' => $status,
            'likes_count' => $post->likes()->count()
        ]);
    }
}
