<?php

namespace App\Http\Controllers;

use App\Models\Post;
use App\Models\SavedPost;
use Illuminate\Http\Request;

class SavedPostController extends Controller
{
    /**
     * Toggle save/unsave a post for the authenticated user.
     */
    public function toggle(Post $post)
    {
        $userId = auth()->id();

        $saved = SavedPost::where('user_id', $userId)
                          ->where('post_id', $post->id)
                          ->first();

        if ($saved) {
            $saved->delete();
            $status = 'unsaved';
        } else {
            SavedPost::create([
                'user_id' => $userId,
                'post_id' => $post->id,
            ]);
            $status = 'saved';
        }

        return response()->json(['status' => $status]);
    }
}
