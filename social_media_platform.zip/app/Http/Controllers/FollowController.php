<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Follower;
use App\Models\Notification;
use Illuminate\Http\Request;

class FollowController extends Controller
{
    public function toggleFollow(User $user)
    {
        if (auth()->id() === $user->id) {
            return response()->json(['error' => 'You cannot follow yourself.'], 400);
        }

        $follower = Follower::where('follower_id', auth()->id())
                            ->where('following_id', $user->id)
                            ->first();

        if ($follower) {
            $follower->delete();
            $status = 'unfollowed';
        } else {
            Follower::create([
                'follower_id' => auth()->id(),
                'following_id' => $user->id
            ]);
            $status = 'followed';

            $actor = auth()->user();
            $actorName = $actor->username ?: $actor->name;

            Notification::create([
                'user_id' => $user->id,
                'type' => 'follow',
                'title' => 'New follower',
                'message' => $actorName . ' started following you.',
                'data' => [
                    'url' => route('profile.show', $actor->username ?? $actor->id, absolute: false),
                    'actor_id' => $actor->id,
                ],
            ]);
        }

        return response()->json([
            'status' => $status,
            'followers_count' => $user->followers()->count()
        ]);
    }
}
