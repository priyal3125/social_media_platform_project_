<?php

namespace App\Http\Controllers;

use App\Models\Story;
use Illuminate\Http\Request;

class StoryController extends Controller
{
    public function store(Request $request)
    {
        $request->validate([
            'image' => 'required|image|max:10240', // 10MB limit
        ]);

        $path = $request->file('image')->store('stories', 'public');

        Story::create([
            'user_id' => auth()->id(),
            'media' => $path,
            'expires_at' => now()->addHours(24),
        ]);

        return back()->with('success', 'Story uploaded successfully!');
    }
}
