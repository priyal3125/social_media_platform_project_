<?php

namespace App\Http\Controllers;

use App\Models\Post;
use App\Models\Comment;
use App\Models\Notification;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class CommentController extends Controller
{
    public function store(Request $request, Post $post)
    {
        $request->validate([
            'comment' => 'required|string|max:1000'
        ]);

        $comment = new Comment();
        $comment->post_id = $post->id;
        $comment->user_id = auth()->id();
        $comment->comment = $request->comment;
        $comment->save();

        if ($post->user_id !== auth()->id()) {
            $actor = auth()->user();
            $actorName = $actor->username ?: $actor->name;
            $target = $post->video ? 'reel' : 'post';
            $url = $post->video
                ? route('reels.index', ['scope' => 'all'], absolute: false) . '#reel-' . $post->id
                : route('home', absolute: false) . '#post-' . $post->id;

            $preview = trim((string) $request->comment);
            if ($preview !== '') {
                $preview = Str::limit($preview, 80);
            }

            Notification::create([
                'user_id' => $post->user_id,
                'type' => 'comment',
                'title' => 'New comment',
                'message' => $actorName . ' commented on your ' . $target . ($preview !== '' ? ': ' . $preview : '.'),
                'data' => [
                    'url' => $url,
                    'actor_id' => $actor->id,
                    'post_id' => $post->id,
                    'comment_id' => $comment->id,
                ],
            ]);
        }

        // Load user to return in JSON
        $comment->load('user');

        return response()->json([
            'status' => 'success',
            'comment' => $comment,
            'user' => [
                'name' => $comment->user->name,
                'profile_photo' => $comment->user->profile_photo ? asset('storage/'.$comment->user->profile_photo) : null
            ]
        ]);
    }
}
