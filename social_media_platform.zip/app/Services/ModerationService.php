<?php

namespace App\Services;

use App\Models\Report;
use Illuminate\Database\Eloquent\Model;

class ModerationService
{
    /**
     * Update report status and perform action.
     *
     * @param Report $report
     * @param string $status
     * @param string|null $notes
     * @return void
     */
    public function updateStatus(Report $report, string $status, string $notes = null): void
    {
        $report->update([
            'status' => $status,
            'admin_notes' => $notes,
        ]);

        if ($status === 'removed') {
            $this->removeContent($report->reportable);
            AuditLogger::log('removed_content', $report->reportable, "Reason: {$report->reason}. Notes: {$notes}");
        } elseif ($status === 'approved') {
            AuditLogger::log('approved_content', $report->reportable, "Notes: {$notes}");
        }
    }

    /**
     * Delete the reported content.
     *
     * @param Model $content
     * @return void
     */
    protected function removeContent(Model $content): void
    {
        if (method_exists($content, 'delete')) {
            $content->delete();
        }
    }
}
