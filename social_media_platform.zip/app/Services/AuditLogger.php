<?php

namespace App\Services;

use App\Models\AuditLog;
use Illuminate\Support\Facades\Request;

class AuditLogger
{
    /**
     * Log an admin action.
     *
     * @param string $action
     * @param mixed $target
     * @param string|null $details
     * @return void
     */
    public static function log(string $action, $target = null, string $details = null): void
    {
        AuditLog::create([
            'admin_id' => auth()->id(),
            'action' => $action,
            'target_type' => $target ? get_class($target) : null,
            'target_id' => $target ? $target->id : null,
            'ip_address' => Request::ip(),
            'details' => $details,
        ]);
    }
}
