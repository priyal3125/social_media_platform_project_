<?php

namespace App\Console\Commands;

use App\Models\Post;
use Illuminate\Console\Command;

class AssignPostCategories extends Command
{
    protected $signature   = 'posts:assign-categories';
    protected $description = 'Assign random categories to posts that have no category set';

    private array $categories = ['Travel', 'Food', 'Nature', 'Art', 'Fashion', 'Tech', 'People'];

    private array $hashtagMap = [
        'Travel'  => ['#travel', '#wanderlust', '#adventure', '#explore', '#vacation'],
        'Food'    => ['#food', '#foodie', '#recipe', '#cooking', '#delicious'],
        'Nature'  => ['#nature', '#wildlife', '#outdoors', '#landscape', '#green'],
        'Art'     => ['#art', '#design', '#creative', '#illustration', '#painting'],
        'Fashion' => ['#fashion', '#style', '#ootd', '#outfit', '#trendy'],
        'Tech'    => ['#tech', '#coding', '#developer', '#gadgets', '#innovation'],
        'People'  => ['#people', '#portrait', '#lifestyle', '#community', '#moments'],
    ];

    public function handle(): int
    {
        $count = 0;

        Post::whereNull('category')->chunk(100, function (\Illuminate\Support\Collection $posts) use (&$count) {
            foreach ($posts as $post) {
                $cat  = $this->categories[array_rand($this->categories)];
                $tags = array_slice($this->hashtagMap[$cat], 0, rand(2, 4));
                $post->update([
                    'category' => $cat,
                    'hashtags' => implode(' ', $tags),
                ]);
                $count++;
            }
        });

        $this->info("✅ Done! Assigned categories to {$count} posts.");
        return 0;
    }
}
